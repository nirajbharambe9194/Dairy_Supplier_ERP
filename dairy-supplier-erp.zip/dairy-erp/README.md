# Dairy Supplier ERP — Installation Guide

A PHP 8 (OOP, MVC) + MySQL + Bootstrap 5 ERP for a dairy supplier managing the
**Company → Supplier → Distributor** workflow: purchasing, inventory, daily
demand planning, deliveries, billing, payments, ledgers, reporting and
profitability — with inventory and ledgers updated automatically at every
transaction.

## 1. Requirements

- PHP 8.0+ with extensions: `pdo_mysql`, `mbstring`, `gd` (for PDF/Excel), `zip`
- MySQL 5.7+ / MariaDB 10.3+
- Apache (with `mod_rewrite`) or Nginx
- Composer (optional but recommended — enables real PDF/Excel export)

## 2. Database Setup

```bash
mysql -u root -p -e "CREATE DATABASE dairy_erp CHARACTER SET utf8mb4"
mysql -u root -p dairy_erp < database/schema.sql
mysql -u root -p dairy_erp < database/seed.sql
php database/rehash_admin.php   # sets correct password hashes for your PHP build
```

This creates all tables plus:
- Two starter accounts: **admin / Admin@123** and **staff / Staff@123**
  (change these immediately after first login — see Settings → Users, or add a
  password-change endpoint following the same pattern as the other AJAX
  actions).
- Sample product categories, two demo companies, five demo products, and two
  demo distributors so you can explore the app immediately.

> `database/rehash_admin.php` exists because password hashes are not
> guaranteed portable across every PHP/OpenSSL build — it regenerates the
> seeded users' hashes correctly on your actual server, right after import.

## 3. Application Configuration

Copy the environment template and edit it for your server, then set these as
real environment variables for PHP (Apache `SetEnv`, nginx `fastcgi_param`,
a process manager, etc.) — see `.env.example` for the full list and why a
plain `.env` file isn't auto-loaded:

```
APP_ENV=production
APP_URL=https://your-domain.com/dairy-erp
DB_HOST=127.0.0.1
DB_NAME=dairy_erp
DB_USER=your_db_user
DB_PASS=your_db_password
```

If you don't set environment variables, `config/config.php` falls back to
local-dev defaults (`root`/no password on `127.0.0.1`) — fine for local testing,
**not** for production.

## 4. Web Server

Point your web server's document root at this project's root folder (the one
containing `index.php`). An `.htaccess` is included for Apache (blocks direct
access to `/config`, `/models`, `/controllers`, `/includes`, `/helpers`,
`/database`, and to `.sql`/`.env`/`.md` files). For Nginx, add equivalent
`location` blocks denying those paths, and route everything else through
`index.php`.

Make sure these folders are writable by the web server user:
```bash
chmod -R 755 uploads reports storage_logs
```

## 5. Optional: PDF & Excel Export (DomPDF / PhpSpreadsheet)

The app works fully without this step — invoice "Download PDF" falls back to
a clean printable HTML page, and reports export via client-side CSV. To
enable true PDF and Excel/XLSX generation:

```bash
composer install
```

This installs `dompdf/dompdf` and `phpoffice/phpspreadsheet` per
`composer.json`. `config/config.php` auto-loads `vendor/autoload.php` if
present — no other change needed. `BillingController::downloadPdf()` already
checks `class_exists('Dompdf\Dompdf')` and switches to real PDF streaming
once installed.

For Excel exports beyond the built-in CSV export on the Reports page, follow
the same pattern: build a `PhpOffice\PhpSpreadsheet\Spreadsheet` in a
controller method, stream it with a `.xlsx` content type, matching how
`BillingController::downloadPdf()` streams PDFs.

## 6. First Login

Visit `APP_URL/index.php` (or just `APP_URL/` if your server's DirectoryIndex
picks up `index.php`). Log in with `admin` / `Admin@123`, then:

1. Go to **Settings** and set your real company name, address, GST, and
   invoice/purchase/delivery number prefixes.
2. Upload your company logo (used on printed invoices once you extend the
   invoice template to include it).
3. Review the seeded companies/products/distributors, edit or delete them,
   and add your real data.

## 7. How the Automatic Updates Work

- **Purchases** (`PurchaseController::store` → `Purchase::createPurchase`)
  increase product stock, record a stock batch, and post a **debit** to the
  company's ledger (you now owe them more).
- **Purchase Returns** decrease stock and post a **credit** to the company
  ledger (credit note).
- **Deliveries** (`DeliveryController::store` → `Delivery::createDelivery`)
  decrease product stock and post a **debit** to the distributor's ledger
  (they now owe you for what was delivered) — this is the automatic sales
  entry described in the spec.
- **Invoices** are generated from a delivery (automatically, if you check
  "Auto-generate invoice", or manually from the Billing page) as the formal
  billing document; they don't double-post the ledger since the delivery
  already did.
- **Payments** (to companies / from distributors) post a **credit** to the
  relevant ledger and reduce the outstanding balance. A distributor payment
  can optionally be tied to an invoice number to mark it paid/partial.

Every model method that changes money or stock runs inside a database
transaction (`PDO::beginTransaction`/`commit`/`rollBack`), so a failure
partway through never leaves inventory and ledgers out of sync.

## 8. Security Notes

- All queries use PDO prepared statements — no raw string concatenation.
- Passwords are hashed with `password_hash()` (bcrypt).
- Every state-changing AJAX request requires a CSRF token
  (`includes/csrf.php`); the front-end automatically attaches it via
  `apiCall()` in `assets/js/app.js`.
- Failed logins lock an account for 15 minutes after 5 attempts
  (`User::recordFailedLogin`).
- Role-based access: **Administrator** has full access; **Staff** can manage
  Purchases, Inventory, Daily Demand, Deliveries, Billing, Payments, and
  Reports, but cannot delete master records (Companies/Products/Distributors)
  or change Settings — see `require_role()` calls in each controller.
- All create/update/delete actions are recorded in `activity_logs`; uncaught
  exceptions are recorded in `error_logs` (see `config/config.php`).

## 9. Project Structure

```
/config          Environment + DB bootstrap
/controllers     One class per module, page rendering + AJAX actions
/models          One class per table/entity, all DB access via PDO
/views           One folder per module; views/layouts holds the shared chrome
/includes        CSRF + auth/role middleware
/helpers         functions.php — sanitization, formatting, doc numbering
/ajax            Single router.php dispatching module+action to a controller
/assets          css/js shared by every page (Bootstrap 5, DataTables, Chart.js via CDN)
/database        schema.sql, seed.sql, rehash_admin.php
/uploads         User-uploaded files (logo, etc.) — must be web-writable
/reports         Generated backups/exports — must be web-writable
```

## 10. What's Included vs. What to Extend

Fully implemented, end-to-end (DB → model → controller → AJAX → UI):
Auth (with lockout), Dashboard (KPIs + charts + alerts), Companies, Products
(+ stock adjustments), Purchases (multi-line, auto stock + ledger), Purchase
Returns, Distributors, Daily Demand (grid entry + copy-previous-day),
Deliveries (multi-line, auto stock + ledger, optional auto-invoice), Billing
(invoice generation, print view, PDF download), Payments (company +
distributor, auto ledger + invoice status), Ledgers (company + distributor,
running balance), Reports (purchase/sales/profit/inventory/financial with CSV
export), Settings (company info, prefixes, logo, backup).

Sketched but intentionally left for you to extend following the same
patterns already in the codebase (each is a small, well-scoped addition, not
a redesign):
- Barcode/QR **rendering** (the `barcode` field and DB support are there;
  wire in a JS library like `jsbarcode` on the product view/print pages).
- Excel import for products/distributors and bulk purchase/demand import
  (PhpSpreadsheet is wired up for export; reading an uploaded sheet follows
  the same `Spreadsheet::load()` pattern).
- Route-wise combined delivery sheet and individual distributor demand
  print-outs (the data — `daily_demands` joined to `distributors`/`products`
  — is already queryable via `DailyDemand::getForDate()`; add a print view
  like `views/billing/invoice_print.php` that groups by route).
- User management CRUD (list view is already in Settings → Users; add
  create/edit/deactivate following `CompanyController`'s CRUD pattern).
- Notifications panel (the underlying queries — low stock, expiring
  products, pending payments, credit limit exceeded — all already exist as
  model methods used by the dashboard; a bell-icon dropdown can reuse them).
