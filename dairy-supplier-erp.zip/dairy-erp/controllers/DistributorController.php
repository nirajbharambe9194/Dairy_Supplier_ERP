<?php

class DistributorController
{
    private Distributor $model;

    public function __construct()
    {
        $this->model = new Distributor();
    }

    public function index(): void
    {
        require_login();
        $routes = $this->model->routes();
        require APP_ROOT . '/views/distributors/index.php';
    }

    public function list(): void
    {
        require_login();
        $term = clean($_GET['term'] ?? '');
        $route = clean($_GET['route'] ?? '');
        $status = clean($_GET['status'] ?? '');
        $rows = $this->model->search($term, $route, $status);
        foreach ($rows as &$row) {
            $row['outstanding_balance'] = $this->model->getOutstandingBalance((int)$row['id']);
        }
        json_response(true, '', ['data' => $rows]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['distributor_name']);
        try {
            $id = $this->model->insert([
                'distributor_code' => $this->model->generateCode(),
                'distributor_name' => $data['distributor_name'],
                'shop_name' => clean($_POST['shop_name'] ?? ''),
                'address' => clean($_POST['address'] ?? ''),
                'route' => clean($_POST['route'] ?? ''),
                'city' => clean($_POST['city'] ?? ''),
                'state' => clean($_POST['state'] ?? ''),
                'phone' => clean($_POST['phone'] ?? ''),
                'email' => clean($_POST['email'] ?? ''),
                'gst_number' => clean($_POST['gst_number'] ?? ''),
                'payment_type' => in_array($_POST['payment_type'] ?? 'credit', ['cash', 'credit']) ? $_POST['payment_type'] : 'credit',
                'credit_limit' => (float)($_POST['credit_limit'] ?? 0),
                'opening_balance' => (float)($_POST['opening_balance'] ?? 0),
                'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
            ]);
            log_activity('create', 'distributors', "Created distributor #$id");
            json_response(true, 'Distributor added successfully.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save distributor.', [], 500);
        }
    }

    public function update(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id || !$this->model->find($id)) {
            json_response(false, 'Distributor not found.', [], 404);
        }
        $data = require_fields(['distributor_name']);
        $this->model->update($id, [
            'distributor_name' => $data['distributor_name'],
            'shop_name' => clean($_POST['shop_name'] ?? ''),
            'address' => clean($_POST['address'] ?? ''),
            'route' => clean($_POST['route'] ?? ''),
            'city' => clean($_POST['city'] ?? ''),
            'state' => clean($_POST['state'] ?? ''),
            'phone' => clean($_POST['phone'] ?? ''),
            'email' => clean($_POST['email'] ?? ''),
            'gst_number' => clean($_POST['gst_number'] ?? ''),
            'payment_type' => in_array($_POST['payment_type'] ?? 'credit', ['cash', 'credit']) ? $_POST['payment_type'] : 'credit',
            'credit_limit' => (float)($_POST['credit_limit'] ?? 0),
            'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
        ]);
        log_activity('update', 'distributors', "Updated distributor #$id");
        json_response(true, 'Distributor updated successfully.');
    }

    public function destroy(): void
    {
        require_role(['admin']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        try {
            $this->model->delete($id);
            log_activity('delete', 'distributors', "Deleted distributor #$id");
            json_response(true, 'Distributor deleted.');
        } catch (Throwable $e) {
            json_response(false, 'Cannot delete: this distributor has delivery/ledger history.', [], 409);
        }
    }

    public function profile(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $distributor = $this->model->find($id);
        if (!$distributor) {
            redirect('index.php?page=distributors');
        }
        $ledger = $this->model->getLedger($id);
        $outstanding = $this->model->getOutstandingBalance($id);
        require APP_ROOT . '/views/distributors/profile.php';
    }
}
