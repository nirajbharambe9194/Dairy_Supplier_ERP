<?php

class PurchaseReturnController
{
    private PurchaseReturn $model;

    public function __construct()
    {
        $this->model = new PurchaseReturn();
    }

    public function index(): void
    {
        require_login();
        $companies = (new Company())->search('', 'active');
        $products = (new Product())->search('', 0, 'active');
        require APP_ROOT . '/views/purchase_returns/index.php';
    }

    public function list(): void
    {
        require_login();
        $filters = ['from' => clean($_GET['from'] ?? ''), 'to' => clean($_GET['to'] ?? '')];
        json_response(true, '', ['data' => $this->model->listWithFilters($filters)]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['company_id', 'product_id', 'quantity', 'rate']);
        if ((float)$data['quantity'] <= 0) {
            json_response(false, 'Quantity must be greater than zero.', [], 422);
        }
        try {
            $id = $this->model->createReturn([
                'return_date' => clean($_POST['return_date'] ?? date('Y-m-d')),
                'company_id' => (int)$data['company_id'],
                'product_id' => (int)$data['product_id'],
                'batch_number' => clean($_POST['batch_number'] ?? ''),
                'quantity' => (float)$data['quantity'],
                'rate' => (float)$data['rate'],
                'reason' => clean($_POST['reason'] ?? ''),
                'credit_note_no' => clean($_POST['credit_note_no'] ?? ''),
                'created_by' => current_user_id(),
            ]);
            log_activity('create', 'purchase_returns', "Created purchase return #$id");
            json_response(true, 'Return recorded. Inventory and company ledger updated automatically.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save the return.', [], 500);
        }
    }
}
