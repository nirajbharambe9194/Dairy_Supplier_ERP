<?php

class LedgerController
{
    public function index(): void
    {
        require_login();
        $companies = (new Company())->search('', 'active');
        $distributors = (new Distributor())->search('', '', 'active');
        require APP_ROOT . '/views/ledgers/index.php';
    }

    public function companyLedger(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $model = new Company();
        $company = $model->find($id);
        if (!$company) {
            json_response(false, 'Company not found.', [], 404);
        }
        json_response(true, '', [
            'data' => $model->getLedger($id),
            'company' => $company,
            'outstanding' => $model->getOutstandingBalance($id),
        ]);
    }

    public function distributorLedger(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $model = new Distributor();
        $distributor = $model->find($id);
        if (!$distributor) {
            json_response(false, 'Distributor not found.', [], 404);
        }
        json_response(true, '', [
            'data' => $model->getLedger($id),
            'distributor' => $distributor,
            'outstanding' => $model->getOutstandingBalance($id),
        ]);
    }
}
