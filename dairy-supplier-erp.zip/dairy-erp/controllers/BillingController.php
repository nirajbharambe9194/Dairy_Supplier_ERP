<?php

class BillingController
{
    private Invoice $model;

    public function __construct()
    {
        $this->model = new Invoice();
    }

    public function index(): void
    {
        require_login();
        $distributors = (new Distributor())->search('', '', 'active');
        require APP_ROOT . '/views/billing/index.php';
    }

    public function list(): void
    {
        require_login();
        $filters = [
            'from' => clean($_GET['from'] ?? ''),
            'to' => clean($_GET['to'] ?? ''),
            'distributor_id' => (int)($_GET['distributor_id'] ?? 0),
            'status' => clean($_GET['status'] ?? ''),
        ];
        json_response(true, '', ['data' => $this->model->listWithFilters($filters)]);
    }

    public function generate(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $deliveryId = (int)($_POST['delivery_id'] ?? 0);
        if (!$deliveryId) {
            json_response(false, 'Please select a delivery to bill.', [], 422);
        }
        try {
            $id = $this->model->generateFromDelivery($deliveryId, (int)current_user_id());
            log_activity('create', 'invoices', "Generated invoice #$id from delivery #$deliveryId");
            json_response(true, 'Invoice generated successfully.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not generate invoice: ' . $e->getMessage(), [], 500);
        }
    }

    /** Renders the print-friendly invoice view (also used as the DomPDF source HTML). */
    public function view(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $invoice = $this->model->getWithItems($id);
        if (!$invoice) {
            redirect('index.php?page=billing');
        }
        require APP_ROOT . '/views/billing/invoice_print.php';
    }

    /** Streams a PDF of the invoice using DomPDF (see /vendor setup in the install guide). */
    public function downloadPdf(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $invoice = $this->model->getWithItems($id);
        if (!$invoice) {
            http_response_code(404);
            die('Invoice not found.');
        }

        ob_start();
        require APP_ROOT . '/views/billing/invoice_print.php';
        $html = ob_get_clean();

        if (!class_exists('Dompdf\Dompdf')) {
            // Vendor library not installed yet — fall back to a printable HTML page
            // and instruct the admin to run `composer require dompdf/dompdf`.
            header('Content-Type: text/html');
            echo $html;
            echo '<!-- DomPDF is not installed. Run `composer install` per the install guide to enable true PDF downloads. -->';
            exit;
        }

        $dompdf = new \Dompdf\Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("invoice-{$invoice['invoice_no']}.pdf", ['Attachment' => true]);
        exit;
    }
}
