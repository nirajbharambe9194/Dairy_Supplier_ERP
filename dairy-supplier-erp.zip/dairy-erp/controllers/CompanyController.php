<?php

class CompanyController
{
    private Company $model;

    public function __construct()
    {
        $this->model = new Company();
    }

    public function index(): void
    {
        require_login();
        require APP_ROOT . '/views/companies/index.php';
    }

    public function list(): void
    {
        require_login();
        $term = clean($_GET['term'] ?? '');
        $status = clean($_GET['status'] ?? '');
        json_response(true, '', ['data' => $this->model->search($term, $status)]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['company_name']);

        try {
            $id = $this->model->insert([
                'company_code' => $this->model->generateCode(),
                'company_name' => $data['company_name'],
                'contact_person' => clean($_POST['contact_person'] ?? ''),
                'address' => clean($_POST['address'] ?? ''),
                'city' => clean($_POST['city'] ?? ''),
                'state' => clean($_POST['state'] ?? ''),
                'country' => clean($_POST['country'] ?? 'India'),
                'gst_number' => clean($_POST['gst_number'] ?? ''),
                'pan_number' => clean($_POST['pan_number'] ?? ''),
                'phone' => clean($_POST['phone'] ?? ''),
                'email' => clean($_POST['email'] ?? ''),
                'payment_terms' => clean($_POST['payment_terms'] ?? ''),
                'credit_limit' => (float)($_POST['credit_limit'] ?? 0),
                'opening_balance' => (float)($_POST['opening_balance'] ?? 0),
                'bank_name' => clean($_POST['bank_name'] ?? ''),
                'bank_account_no' => clean($_POST['bank_account_no'] ?? ''),
                'bank_ifsc' => clean($_POST['bank_ifsc'] ?? ''),
                'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
            ]);
            log_activity('create', 'companies', "Created company #$id");
            json_response(true, 'Company added successfully.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save company. It may already exist.', [], 500);
        }
    }

    public function update(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id || !$this->model->find($id)) {
            json_response(false, 'Company not found.', [], 404);
        }
        $data = require_fields(['company_name']);

        $this->model->update($id, [
            'company_name' => $data['company_name'],
            'contact_person' => clean($_POST['contact_person'] ?? ''),
            'address' => clean($_POST['address'] ?? ''),
            'city' => clean($_POST['city'] ?? ''),
            'state' => clean($_POST['state'] ?? ''),
            'country' => clean($_POST['country'] ?? 'India'),
            'gst_number' => clean($_POST['gst_number'] ?? ''),
            'pan_number' => clean($_POST['pan_number'] ?? ''),
            'phone' => clean($_POST['phone'] ?? ''),
            'email' => clean($_POST['email'] ?? ''),
            'payment_terms' => clean($_POST['payment_terms'] ?? ''),
            'credit_limit' => (float)($_POST['credit_limit'] ?? 0),
            'bank_name' => clean($_POST['bank_name'] ?? ''),
            'bank_account_no' => clean($_POST['bank_account_no'] ?? ''),
            'bank_ifsc' => clean($_POST['bank_ifsc'] ?? ''),
            'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
        ]);
        log_activity('update', 'companies', "Updated company #$id");
        json_response(true, 'Company updated successfully.');
    }

    public function destroy(): void
    {
        require_role(['admin']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) {
            json_response(false, 'Invalid company.', [], 422);
        }
        try {
            $this->model->delete($id);
            log_activity('delete', 'companies', "Deleted company #$id");
            json_response(true, 'Company deleted.');
        } catch (Throwable $e) {
            json_response(false, 'Cannot delete: this company has related purchase/ledger records.', [], 409);
        }
    }

    public function profile(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $company = $this->model->find($id);
        if (!$company) {
            redirect('index.php?page=companies');
        }
        $ledger = $this->model->getLedger($id);
        $outstanding = $this->model->getOutstandingBalance($id);
        require APP_ROOT . '/views/companies/profile.php';
    }
}
