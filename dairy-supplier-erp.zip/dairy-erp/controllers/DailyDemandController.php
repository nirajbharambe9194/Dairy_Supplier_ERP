<?php

class DailyDemandController
{
    private DailyDemand $model;

    public function __construct()
    {
        $this->model = new DailyDemand();
    }

    public function index(): void
    {
        require_login();
        $distributors = (new Distributor())->search('', '', 'active');
        $products = (new Product())->search('', 0, 'active');
        require APP_ROOT . '/views/daily_demand/index.php';
    }

    public function list(): void
    {
        require_login();
        $date = clean($_GET['date'] ?? date('Y-m-d'));
        $distributorId = (int)($_GET['distributor_id'] ?? 0);
        json_response(true, '', ['data' => $this->model->getForDate($date, $distributorId)]);
    }

    public function save(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $lines = json_decode($_POST['lines'] ?? '[]', true);
        $date = clean($_POST['demand_date'] ?? date('Y-m-d'));
        if (empty($lines) || !is_array($lines)) {
            json_response(false, 'No demand lines to save.', [], 422);
        }
        try {
            foreach ($lines as $line) {
                $this->model->upsert(
                    $date,
                    (int)$line['distributor_id'],
                    (int)$line['product_id'],
                    (float)($line['morning_qty'] ?? 0),
                    (float)($line['evening_qty'] ?? 0),
                    (float)($line['rate'] ?? 0),
                    clean($line['remarks'] ?? '')
                );
            }
            log_activity('save', 'daily_demands', "Saved demand for $date");
            json_response(true, 'Daily demand saved.');
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save demand.', [], 500);
        }
    }

    public function copyPrevious(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $date = clean($_POST['demand_date'] ?? date('Y-m-d'));
        $distributorId = (int)($_POST['distributor_id'] ?? 0);
        $count = $this->model->copyFromPreviousDay($date, $distributorId);
        json_response(true, "Copied $count line(s) from the previous day.", ['count' => $count]);
    }

    public function deleteLine(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        $this->model->deleteLine($id);
        json_response(true, 'Line removed.');
    }
}
