<?php

class ProductController
{
    private Product $model;

    public function __construct()
    {
        $this->model = new Product();
    }

    public function index(): void
    {
        require_login();
        $categories = $this->model->categories();
        require APP_ROOT . '/views/products/index.php';
    }

    public function list(): void
    {
        require_login();
        $term = clean($_GET['term'] ?? '');
        $category = (int)($_GET['category_id'] ?? 0);
        $status = clean($_GET['status'] ?? '');
        json_response(true, '', ['data' => $this->model->search($term, $category, $status)]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['product_name', 'unit']);

        try {
            $id = $this->model->insert([
                'product_code' => $this->model->generateCode(),
                'product_name' => $data['product_name'],
                'category_id' => (int)($_POST['category_id'] ?? 0) ?: null,
                'brand' => clean($_POST['brand'] ?? ''),
                'unit' => $data['unit'],
                'barcode' => clean($_POST['barcode'] ?? ''),
                'purchase_price' => (float)($_POST['purchase_price'] ?? 0),
                'selling_price' => (float)($_POST['selling_price'] ?? 0),
                'gst_percent' => (float)($_POST['gst_percent'] ?? 0),
                'current_stock' => (float)($_POST['current_stock'] ?? 0),
                'minimum_stock' => (float)($_POST['minimum_stock'] ?? 0),
                'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
            ]);
            log_activity('create', 'products', "Created product #$id");
            json_response(true, 'Product added successfully.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save product. Check that the code/barcode is unique.', [], 500);
        }
    }

    public function update(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id || !$this->model->find($id)) {
            json_response(false, 'Product not found.', [], 404);
        }
        $data = require_fields(['product_name', 'unit']);

        $this->model->update($id, [
            'product_name' => $data['product_name'],
            'category_id' => (int)($_POST['category_id'] ?? 0) ?: null,
            'brand' => clean($_POST['brand'] ?? ''),
            'unit' => $data['unit'],
            'barcode' => clean($_POST['barcode'] ?? ''),
            'purchase_price' => (float)($_POST['purchase_price'] ?? 0),
            'selling_price' => (float)($_POST['selling_price'] ?? 0),
            'gst_percent' => (float)($_POST['gst_percent'] ?? 0),
            'minimum_stock' => (float)($_POST['minimum_stock'] ?? 0),
            'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active',
        ]);
        log_activity('update', 'products', "Updated product #$id");
        json_response(true, 'Product updated successfully.');
    }

    public function destroy(): void
    {
        require_role(['admin']);
        csrf_verify_or_fail();
        $id = (int)($_POST['id'] ?? 0);
        try {
            $this->model->delete($id);
            log_activity('delete', 'products', "Deleted product #$id");
            json_response(true, 'Product deleted.');
        } catch (Throwable $e) {
            json_response(false, 'Cannot delete: this product has purchase/delivery history.', [], 409);
        }
    }

    public function adjustStock(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $id = (int)($_POST['product_id'] ?? 0);
        $qty = (float)($_POST['quantity'] ?? 0);
        $direction = $_POST['direction'] ?? 'increase';
        $remarks = clean($_POST['remarks'] ?? 'Manual stock adjustment');
        if (!$id || $qty <= 0) {
            json_response(false, 'Invalid adjustment.', [], 422);
        }
        $today = date('Y-m-d');
        if ($direction === 'increase') {
            $this->model->increaseStock($id, $qty, 'adjustment', $today, null, null, $remarks);
        } else {
            $this->model->decreaseStock($id, $qty, 'adjustment', $today, null, null, $remarks);
        }
        log_activity('stock_adjust', 'products', "Product #$id $direction by $qty");
        json_response(true, 'Stock adjusted successfully.');
    }
}
