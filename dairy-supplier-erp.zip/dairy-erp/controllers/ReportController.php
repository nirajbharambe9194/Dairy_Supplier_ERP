<?php

class ReportController
{
    private Report $model;

    public function __construct()
    {
        $this->model = new Report();
    }

    public function index(): void
    {
        require_login();
        require APP_ROOT . '/views/reports/index.php';
    }

    public function purchaseReport(): void
    {
        require_login();
        $filters = [
            'from' => clean($_GET['from'] ?? date('Y-m-01')),
            'to' => clean($_GET['to'] ?? date('Y-m-d')),
            'company_id' => (int)($_GET['company_id'] ?? 0),
        ];
        json_response(true, '', ['data' => (new Purchase())->listWithFilters($filters)]);
    }

    public function salesReport(): void
    {
        require_login();
        $filters = [
            'from' => clean($_GET['from'] ?? date('Y-m-01')),
            'to' => clean($_GET['to'] ?? date('Y-m-d')),
            'distributor_id' => (int)($_GET['distributor_id'] ?? 0),
        ];
        json_response(true, '', ['data' => (new Invoice())->listWithFilters($filters)]);
    }

    public function profitReport(): void
    {
        require_login();
        $from = clean($_GET['from'] ?? date('Y-m-01'));
        $to = clean($_GET['to'] ?? date('Y-m-d'));
        $by = clean($_GET['by'] ?? 'product'); // product | distributor
        $data = $by === 'distributor'
            ? $this->model->distributorWiseProfit($from, $to)
            : $this->model->productWiseProfit($from, $to);
        json_response(true, '', ['data' => $data]);
    }

    public function inventoryReport(): void
    {
        require_login();
        $type = clean($_GET['type'] ?? 'stock'); // stock | movement | low_stock | expiring | valuation
        $productModel = new Product();
        switch ($type) {
            case 'low_stock':
                $data = $productModel->lowStock();
                break;
            case 'expiring':
                $data = $productModel->expiringSoon((int)($_GET['days'] ?? 7));
                break;
            case 'movement':
                $data = $this->model->stockMovementReport(
                    clean($_GET['from'] ?? date('Y-m-01')),
                    clean($_GET['to'] ?? date('Y-m-d')),
                    (int)($_GET['product_id'] ?? 0)
                );
                break;
            case 'valuation':
            default:
                $data = $this->model->stockValuationReport();
        }
        json_response(true, '', ['data' => $data]);
    }

    public function financialReport(): void
    {
        require_login();
        $type = clean($_GET['type'] ?? 'company_outstanding');
        switch ($type) {
            case 'distributor_outstanding':
                $distModel = new Distributor();
                $rows = $distModel->search('', '', 'active');
                foreach ($rows as &$r) {
                    $r['outstanding_balance'] = $distModel->getOutstandingBalance((int)$r['id']);
                }
                $data = $rows;
                break;
            case 'collection':
                $data = $this->model->collectionReport(
                    clean($_GET['from'] ?? date('Y-m-01')),
                    clean($_GET['to'] ?? date('Y-m-d'))
                );
                break;
            case 'company_outstanding':
            default:
                $companyModel = new Company();
                $rows = $companyModel->search('', 'active');
                foreach ($rows as &$r) {
                    $r['outstanding_balance'] = $companyModel->getOutstandingBalance((int)$r['id']);
                }
                $data = $rows;
        }
        json_response(true, '', ['data' => $data]);
    }
}
