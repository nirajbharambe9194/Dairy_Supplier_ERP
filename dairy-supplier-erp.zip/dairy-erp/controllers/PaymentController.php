<?php

class PaymentController
{
    public function index(): void
    {
        require_login();
        $companies = (new Company())->search('', 'active');
        $distributors = (new Distributor())->search('', '', 'active');
        require APP_ROOT . '/views/payments/index.php';
    }

    public function listCompanyPayments(): void
    {
        require_login();
        $model = new CompanyPayment();
        $filters = [
            'from' => clean($_GET['from'] ?? ''),
            'to' => clean($_GET['to'] ?? ''),
            'company_id' => (int)($_GET['company_id'] ?? 0),
        ];
        json_response(true, '', ['data' => $model->listWithFilters($filters)]);
    }

    public function listDistributorPayments(): void
    {
        require_login();
        $model = new DistributorPayment();
        $filters = [
            'from' => clean($_GET['from'] ?? ''),
            'to' => clean($_GET['to'] ?? ''),
            'distributor_id' => (int)($_GET['distributor_id'] ?? 0),
        ];
        json_response(true, '', ['data' => $model->listWithFilters($filters)]);
    }

    public function storeCompanyPayment(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['company_id', 'amount', 'payment_method']);
        if ((float)$data['amount'] <= 0) {
            json_response(false, 'Amount must be greater than zero.', [], 422);
        }
        try {
            $id = (new CompanyPayment())->recordPayment([
                'company_id' => (int)$data['company_id'],
                'payment_date' => clean($_POST['payment_date'] ?? date('Y-m-d')),
                'invoice_no' => clean($_POST['invoice_no'] ?? ''),
                'payment_method' => $data['payment_method'],
                'transaction_reference' => clean($_POST['transaction_reference'] ?? ''),
                'amount' => (float)$data['amount'],
                'remarks' => clean($_POST['remarks'] ?? ''),
                'created_by' => current_user_id(),
            ]);
            log_activity('create', 'company_payments', "Recorded company payment #$id");
            json_response(true, 'Payment recorded. Company ledger updated automatically.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not record payment.', [], 500);
        }
    }

    public function storeDistributorPayment(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();
        $data = require_fields(['distributor_id', 'amount', 'payment_method']);
        if ((float)$data['amount'] <= 0) {
            json_response(false, 'Amount must be greater than zero.', [], 422);
        }
        try {
            $id = (new DistributorPayment())->recordPayment([
                'distributor_id' => (int)$data['distributor_id'],
                'payment_date' => clean($_POST['payment_date'] ?? date('Y-m-d')),
                'invoice_no' => clean($_POST['invoice_no'] ?? ''),
                'payment_method' => $data['payment_method'],
                'transaction_reference' => clean($_POST['transaction_reference'] ?? ''),
                'amount' => (float)$data['amount'],
                'remarks' => clean($_POST['remarks'] ?? ''),
                'created_by' => current_user_id(),
            ]);
            log_activity('create', 'distributor_payments', "Recorded distributor payment #$id");
            json_response(true, 'Payment recorded. Distributor ledger updated automatically.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not record payment.', [], 500);
        }
    }
}
