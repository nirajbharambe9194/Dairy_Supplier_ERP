<?php

class AuthController
{
    private User $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function showLogin(): void
    {
        if (is_logged_in()) {
            redirect('index.php?page=dashboard');
        }
        require APP_ROOT . '/views/auth/login.php';
    }

    public function login(): void
    {
        if (!csrf_verify($_POST['csrf_token'] ?? null)) {
            $_SESSION['login_error'] = 'Your session expired. Please try again.';
            redirect('index.php?page=login');
        }

        $username = clean($_POST['username'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        $user = $this->userModel->findByUsername($username);

        if (!$user) {
            log_activity('login_failed', 'auth', "Unknown username: $username");
            $_SESSION['login_error'] = 'Invalid username or password.';
            redirect('index.php?page=login');
        }

        if ($this->userModel->isLocked($user)) {
            $_SESSION['login_error'] = 'Account temporarily locked due to repeated failed attempts. Try again later.';
            redirect('index.php?page=login');
        }

        if ($user['status'] !== 'active') {
            $_SESSION['login_error'] = 'This account has been deactivated. Contact your administrator.';
            redirect('index.php?page=login');
        }

        if (!password_verify($password, $user['password_hash'])) {
            $this->userModel->recordFailedLogin((int)$user['id']);
            log_activity('login_failed', 'auth', "Bad password for: $username");
            $_SESSION['login_error'] = 'Invalid username or password.';
            redirect('index.php?page=login');
        }

        // Successful login.
        $this->userModel->resetFailedLogins((int)$user['id']);
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role_name'] = $user['role_name'];

        log_activity('login_success', 'auth', "User $username logged in");

        $redirectTo = $_SESSION['redirect_after_login'] ?? null;
        unset($_SESSION['redirect_after_login']);

        if ($redirectTo) {
            // $redirectTo came from $_SERVER['REQUEST_URI'] in require_login(), which is
            // already a full path from the domain root (e.g. /dairy-erp/index.php?page=x) —
            // prefixing it with APP_URL again would duplicate the folder and 404.
            header('Location: ' . $redirectTo);
        } else {
            header('Location: ' . APP_URL . '/index.php?page=dashboard');
        }
        exit;
    }

    public function logout(): void
    {
        if (is_logged_in()) {
            log_activity('logout', 'auth', "User {$_SESSION['username']} logged out");
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        redirect('index.php?page=login');
    }
}
