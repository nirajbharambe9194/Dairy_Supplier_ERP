<?php

class PurchaseController
{
    private Purchase $model;

    public function __construct()
    {
        $this->model = new Purchase();
    }

    public function index(): void
    {
        require_login();
        $companies = (new Company())->search('', 'active');
        $products = (new Product())->search('', 0, 'active');
        require APP_ROOT . '/views/purchases/index.php';
    }

    public function list(): void
    {
        require_login();
        $filters = [
            'from' => clean($_GET['from'] ?? ''),
            'to' => clean($_GET['to'] ?? ''),
            'company_id' => (int)($_GET['company_id'] ?? 0),
            'payment_status' => clean($_GET['payment_status'] ?? ''),
        ];
        json_response(true, '', ['data' => $this->model->listWithFilters($filters)]);
    }

    public function view(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $purchase = $this->model->getWithItems($id);
        if (!$purchase) {
            json_response(false, 'Purchase not found.', [], 404);
        }
        json_response(true, '', ['data' => $purchase]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();

        $companyId = (int)($_POST['company_id'] ?? 0);
        $purchaseDate = clean($_POST['purchase_date'] ?? date('Y-m-d'));
        $items = json_decode($_POST['items'] ?? '[]', true);

        if (!$companyId || empty($items) || !is_array($items)) {
            json_response(false, 'Please select a company and add at least one product line.', [], 422);
        }

        foreach ($items as $item) {
            if (empty($item['product_id']) || (float)($item['quantity'] ?? 0) <= 0 || (float)($item['purchase_price'] ?? -1) < 0) {
                json_response(false, 'Each item requires a product, quantity, and purchase price.', [], 422);
            }
        }

        try {
            $id = $this->model->createPurchase([
                'company_id' => $companyId,
                'purchase_date' => $purchaseDate,
                'company_invoice_no' => clean($_POST['company_invoice_no'] ?? ''),
                'invoice_date' => clean($_POST['invoice_date'] ?? '') ?: null,
                'freight_charges' => (float)($_POST['freight_charges'] ?? 0),
                'discount_amount' => (float)($_POST['discount_amount'] ?? 0),
                'remarks' => clean($_POST['remarks'] ?? ''),
                'created_by' => current_user_id(),
            ], $items);

            log_activity('create', 'purchases', "Created purchase #$id");
            json_response(true, 'Purchase recorded. Inventory and company ledger updated automatically.', ['id' => $id]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save the purchase. Please check the details and try again.', [], 500);
        }
    }
}
