<?php

class SettingsController
{
    public function index(): void
    {
        require_role(['admin']);
        $db = Database::getInstance()->getConnection();
        $settings = [];
        foreach ($db->query('SELECT setting_key, setting_value FROM settings') as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        $users = (new User())->all('full_name');
        require APP_ROOT . '/views/settings/index.php';
    }

    public function updateGeneral(): void
    {
        require_role(['admin']);
        csrf_verify_or_fail();
        $db = Database::getInstance()->getConnection();

        $editable = [
            'company_name', 'company_address', 'company_phone', 'company_email', 'company_gst',
            'invoice_prefix', 'purchase_prefix', 'delivery_prefix', 'return_prefix',
            'financial_year_start', 'currency_symbol',
        ];

        $stmt = $db->prepare(
            'INSERT INTO settings (setting_key, setting_value) VALUES (:k,:v)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        foreach ($editable as $key) {
            if (isset($_POST[$key])) {
                $stmt->execute(['k' => $key, 'v' => clean($_POST[$key])]);
            }
        }
        log_activity('update', 'settings', 'Updated general settings');
        json_response(true, 'Settings updated successfully.');
    }

    public function uploadLogo(): void
    {
        require_role(['admin']);
        csrf_verify_or_fail();
        if (empty($_FILES['logo']['tmp_name'])) {
            json_response(false, 'No file uploaded.', [], 422);
        }
        $allowed = ['image/png', 'image/jpeg', 'image/webp'];
        $mime = mime_content_type($_FILES['logo']['tmp_name']);
        if (!in_array($mime, $allowed, true)) {
            json_response(false, 'Only PNG, JPEG, or WEBP images are allowed.', [], 422);
        }
        if ($_FILES['logo']['size'] > 2 * 1024 * 1024) {
            json_response(false, 'Logo must be under 2MB.', [], 422);
        }
        $ext = $mime === 'image/png' ? 'png' : ($mime === 'image/webp' ? 'webp' : 'jpg');
        $filename = 'logo_' . time() . '.' . $ext;
        $dest = UPLOAD_PATH . '/' . $filename;
        if (!move_uploaded_file($_FILES['logo']['tmp_name'], $dest)) {
            json_response(false, 'Could not save the uploaded logo.', [], 500);
        }
        $db = Database::getInstance()->getConnection();
        $db->prepare('INSERT INTO settings (setting_key, setting_value) VALUES ("logo_path", :v)
                      ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)')
            ->execute(['v' => 'uploads/' . $filename]);
        log_activity('update', 'settings', 'Uploaded new company logo');
        json_response(true, 'Logo uploaded successfully.', ['path' => 'uploads/' . $filename]);
    }

    /** Simple mysqldump-based backup. Requires the mysqldump binary on PATH. */
    public function backup(): void
    {
        require_role(['admin']);
        $filename = 'dairy_erp_backup_' . date('Ymd_His') . '.sql';
        $path = REPORT_PATH . '/' . $filename;
        $cmd = sprintf(
            'mysqldump --host=%s --port=%s --user=%s %s %s > %s 2>&1',
            escapeshellarg(DB_HOST),
            escapeshellarg(DB_PORT),
            escapeshellarg(DB_USER),
            DB_PASS !== '' ? '--password=' . escapeshellarg(DB_PASS) : '',
            escapeshellarg(DB_NAME),
            escapeshellarg($path)
        );
        exec($cmd, $output, $code);
        if ($code !== 0 || !file_exists($path)) {
            json_response(false, 'Backup failed. Ensure the mysqldump binary is available on the server PATH.', [], 500);
        }
        log_activity('backup', 'settings', "Created backup $filename");
        json_response(true, 'Backup created successfully.', ['file' => $filename]);
    }
}
