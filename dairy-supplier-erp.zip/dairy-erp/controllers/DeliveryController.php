<?php

class DeliveryController
{
    private Delivery $model;

    public function __construct()
    {
        $this->model = new Delivery();
    }

    public function index(): void
    {
        require_login();
        $distributors = (new Distributor())->search('', '', 'active');
        $products = (new Product())->search('', 0, 'active');
        require APP_ROOT . '/views/deliveries/index.php';
    }

    public function list(): void
    {
        require_login();
        $filters = [
            'from' => clean($_GET['from'] ?? ''),
            'to' => clean($_GET['to'] ?? ''),
            'distributor_id' => (int)($_GET['distributor_id'] ?? 0),
            'route' => clean($_GET['route'] ?? ''),
        ];
        json_response(true, '', ['data' => $this->model->listWithFilters($filters)]);
    }

    public function view(): void
    {
        require_login();
        $id = (int)($_GET['id'] ?? 0);
        $delivery = $this->model->getWithItems($id);
        if (!$delivery) {
            json_response(false, 'Delivery not found.', [], 404);
        }
        json_response(true, '', ['data' => $delivery]);
    }

    public function store(): void
    {
        require_role(['staff']);
        csrf_verify_or_fail();

        $distributorId = (int)($_POST['distributor_id'] ?? 0);
        $deliveryDate = clean($_POST['delivery_date'] ?? date('Y-m-d'));
        $items = json_decode($_POST['items'] ?? '[]', true);
        $generateInvoice = !empty($_POST['generate_invoice']);

        if (!$distributorId || empty($items) || !is_array($items)) {
            json_response(false, 'Please select a distributor and add at least one product line.', [], 422);
        }
        foreach ($items as $item) {
            if (empty($item['product_id']) || (float)($item['delivered_qty'] ?? -1) < 0) {
                json_response(false, 'Each item requires a product and a delivered quantity.', [], 422);
            }
        }

        $distributorModel = new Distributor();
        if ($distributorModel->creditLimitExceeded($distributorId)) {
            // Not a hard block — staff may still proceed for an existing customer relationship —
            // but the caller is informed so they can decide.
            log_activity('credit_limit_alert', 'deliveries', "Distributor #$distributorId over credit limit at delivery time");
        }

        try {
            $id = $this->model->createDelivery([
                'distributor_id' => $distributorId,
                'delivery_date' => $deliveryDate,
                'remarks' => clean($_POST['remarks'] ?? ''),
                'created_by' => current_user_id(),
            ], $items);

            $invoiceId = null;
            if ($generateInvoice) {
                $invoiceId = (new Invoice())->generateFromDelivery($id, (int)current_user_id());
            }

            log_activity('create', 'deliveries', "Created delivery #$id");
            json_response(true, 'Delivery recorded. Inventory and distributor ledger updated automatically.', [
                'id' => $id,
                'invoice_id' => $invoiceId,
            ]);
        } catch (Throwable $e) {
            error_log($e->getMessage());
            json_response(false, 'Could not save the delivery.', [], 500);
        }
    }
}
