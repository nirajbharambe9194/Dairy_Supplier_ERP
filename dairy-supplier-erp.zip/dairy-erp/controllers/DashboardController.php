<?php

class DashboardController
{
    public function index(): void
    {
        require_login();

        $db = Database::getInstance()->getConnection();
        $companyModel = new Company();
        $distributorModel = new Distributor();
        $productModel = new Product();
        $purchaseModel = new Purchase();
        $deliveryModel = new Delivery();
        $invoiceModel = new Invoice();
        $reportModel = new Report();

        $data = [
            'total_companies' => $companyModel->count("status='active'"),
            'total_distributors' => $distributorModel->count("status='active'"),
            'total_products' => $productModel->count("status='active'"),
            'inventory_value' => $productModel->inventoryValue(),
            'todays_purchases' => $purchaseModel->todaysTotal(),
            'todays_deliveries' => $deliveryModel->todaysCount(),
            'todays_sales' => $invoiceModel->todaysSalesTotal(),
            'pending_company_payments' => $companyModel->totalPendingPayments(),
            'pending_distributor_payments' => $distributorModel->totalPendingPayments(),
            'monthly_purchase_cost' => $purchaseModel->monthlyTotal(),
            'monthly_revenue' => $invoiceModel->monthlyRevenue(),
            'gross_profit' => $reportModel->grossProfitThisMonth(),
            'net_profit' => $reportModel->netProfitThisMonth(),
            'low_stock' => $productModel->lowStock(),
            'expiring' => $productModel->expiringSoon(7),
            'recent_purchases' => $purchaseModel->listWithFilters([]),
            'recent_deliveries' => $deliveryModel->listWithFilters([]),
            'sales_chart' => $invoiceModel->monthlyChartData(),
            'purchase_chart' => $purchaseModel->monthlyChartData(),
            'product_sales_chart' => $invoiceModel->productSalesChartData(),
        ];

        $data['recent_purchases'] = array_slice($data['recent_purchases'], 0, 5);
        $data['recent_deliveries'] = array_slice($data['recent_deliveries'], 0, 5);

        $recentPaymentsStmt = $db->query(
            "(SELECT payment_date as pdate, 'Company' as party_type, c.company_name as party_name, amount FROM company_payments cp JOIN companies c ON c.id = cp.company_id ORDER BY cp.id DESC LIMIT 5)
             UNION ALL
             (SELECT payment_date as pdate, 'Distributor' as party_type, d.distributor_name as party_name, amount FROM distributor_payments dp JOIN distributors d ON d.id = dp.distributor_id ORDER BY dp.id DESC LIMIT 5)
             ORDER BY pdate DESC LIMIT 5"
        );
        $data['recent_payments'] = $recentPaymentsStmt->fetchAll();

        require APP_ROOT . '/views/dashboard/index.php';
    }
}
