/**
 * Shared front-end helpers used across every module page.
 * Depends on jQuery + Bootstrap 5 (loaded in views/layouts/footer.php).
 */

/** Show a Bootstrap toast. type: 'success' | 'danger' | 'warning' | 'info' */
function showToast(message, type = 'success') {
  const id = 't' + Date.now();
  const html = `
    <div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert">
      <div class="d-flex">
        <div class="toast-body">${message}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>`;
  $('#toastHost').append(html);
  const el = new bootstrap.Toast(document.getElementById(id), { delay: 4000 });
  el.show();
  document.getElementById(id).addEventListener('hidden.bs.toast', () => $('#' + id).remove());
}

/**
 * Central AJAX call to the router. Automatically attaches the CSRF token
 * for state-changing requests and surfaces a toast on failure.
 */
function apiCall(module, action, data = {}, method = 'POST') {
  const url = `${window.APP_URL}/ajax/router.php?module=${encodeURIComponent(module)}&action=${encodeURIComponent(action)}`;
  const payload = method === 'POST' ? Object.assign({ csrf_token: window.CSRF_TOKEN }, data) : data;

  return $.ajax({
    url,
    method,
    data: payload,
    dataType: 'json',
  }).fail(function (xhr) {
    let msg = 'Something went wrong. Please try again.';
    try {
      const body = JSON.parse(xhr.responseText);
      if (body && body.message) msg = body.message;
    } catch (e) { /* ignore parse errors, use default message */ }
    showToast(msg, 'danger');
  });
}

function money(amount) {
  const n = Number(amount || 0);
  return `${window.CURRENCY} ${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

$(function () {
  // Sidebar collapse (desktop) / slide-in (mobile)
  $('#sidebarToggle').on('click', () => $('#sidebar').toggleClass('collapsed'));
  $('#mobileSidebarToggle').on('click', () => $('#sidebar').toggleClass('mobile-open'));

  // Dark / light mode, persisted in-memory for the session via a cookie-free approach:
  // we just toggle the attribute; no localStorage per artifact/browser-storage rules,
  // but this is a full app context (not a Claude artifact) so a lightweight cookie is fine here.
  const root = document.documentElement;
  $('#themeToggle').on('click', function () {
    const isDark = root.getAttribute('data-bs-theme') === 'dark';
    root.setAttribute('data-bs-theme', isDark ? 'light' : 'dark');
    $(this).find('i').toggleClass('fa-moon fa-sun');
    document.cookie = `dairy_erp_theme=${isDark ? 'light' : 'dark'};path=/;max-age=31536000`;
  });
  const savedTheme = document.cookie.split('; ').find(r => r.startsWith('dairy_erp_theme='));
  if (savedTheme && savedTheme.split('=')[1] === 'dark') {
    root.setAttribute('data-bs-theme', 'dark');
    $('#themeToggle i').removeClass('fa-moon').addClass('fa-sun');
  }
});
