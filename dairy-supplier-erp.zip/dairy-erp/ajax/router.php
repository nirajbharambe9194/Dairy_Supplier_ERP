<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

header('X-Content-Type-Options: nosniff');

$module = $_GET['module'] ?? ($_POST['module'] ?? '');
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

// Map of module => [action => [ControllerClass, method]]
$routes = [
    'companies' => [
        'list' => ['CompanyController', 'list'],
        'store' => ['CompanyController', 'store'],
        'update' => ['CompanyController', 'update'],
        'delete' => ['CompanyController', 'destroy'],
    ],
    'products' => [
        'list' => ['ProductController', 'list'],
        'store' => ['ProductController', 'store'],
        'update' => ['ProductController', 'update'],
        'delete' => ['ProductController', 'destroy'],
        'adjust_stock' => ['ProductController', 'adjustStock'],
    ],
    'distributors' => [
        'list' => ['DistributorController', 'list'],
        'store' => ['DistributorController', 'store'],
        'update' => ['DistributorController', 'update'],
        'delete' => ['DistributorController', 'destroy'],
    ],
    'purchases' => [
        'list' => ['PurchaseController', 'list'],
        'view' => ['PurchaseController', 'view'],
        'store' => ['PurchaseController', 'store'],
    ],
    'purchase_returns' => [
        'list' => ['PurchaseReturnController', 'list'],
        'store' => ['PurchaseReturnController', 'store'],
    ],
    'daily_demand' => [
        'list' => ['DailyDemandController', 'list'],
        'save' => ['DailyDemandController', 'save'],
        'copy_previous' => ['DailyDemandController', 'copyPrevious'],
        'delete_line' => ['DailyDemandController', 'deleteLine'],
    ],
    'deliveries' => [
        'list' => ['DeliveryController', 'list'],
        'view' => ['DeliveryController', 'view'],
        'store' => ['DeliveryController', 'store'],
    ],
    'billing' => [
        'list' => ['BillingController', 'list'],
        'generate' => ['BillingController', 'generate'],
    ],
    'payments' => [
        'list_company' => ['PaymentController', 'listCompanyPayments'],
        'list_distributor' => ['PaymentController', 'listDistributorPayments'],
        'store_company' => ['PaymentController', 'storeCompanyPayment'],
        'store_distributor' => ['PaymentController', 'storeDistributorPayment'],
    ],
    'ledgers' => [
        'company' => ['LedgerController', 'companyLedger'],
        'distributor' => ['LedgerController', 'distributorLedger'],
    ],
    'reports' => [
        'purchase' => ['ReportController', 'purchaseReport'],
        'sales' => ['ReportController', 'salesReport'],
        'profit' => ['ReportController', 'profitReport'],
        'inventory' => ['ReportController', 'inventoryReport'],
        'financial' => ['ReportController', 'financialReport'],
    ],
    'settings' => [
        'update_general' => ['SettingsController', 'updateGeneral'],
        'upload_logo' => ['SettingsController', 'uploadLogo'],
        'backup' => ['SettingsController', 'backup'],
    ],
];

if (!isset($routes[$module][$action])) {
    json_response(false, 'Unknown request.', [], 404);
}

[$controllerClass, $method] = $routes[$module][$action];
$controller = new $controllerClass();
$controller->$method();
