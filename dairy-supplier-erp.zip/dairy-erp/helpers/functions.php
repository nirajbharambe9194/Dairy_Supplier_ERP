<?php

/** XSS-safe output escaping shorthand. */
function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** Trim + strip tags for basic server-side input sanitization (validation still required). */
function clean(?string $value): string
{
    return trim(strip_tags((string)$value));
}

function format_money($amount): string
{
    $symbol = get_setting('currency_symbol', 'Rs.');
    return $symbol . ' ' . number_format((float)$amount, 2);
}

function format_date(?string $date, string $fmt = 'd-M-Y'): string
{
    if (empty($date) || $date === '0000-00-00') {
        return '-';
    }
    $ts = strtotime($date);
    return $ts ? date($fmt, $ts) : '-';
}

/** Cached settings lookup (settings table is small; one query per request). */
function get_setting(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $db = Database::getInstance()->getConnection();
            foreach ($db->query('SELECT setting_key, setting_value FROM settings') as $row) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        } catch (Throwable $e) {
            error_log('get_setting failed: ' . $e->getMessage());
        }
    }
    return $cache[$key] ?? $default;
}

/**
 * Generate the next sequential document number, e.g. PUR-000123.
 * Uses a row lock on the max existing number to stay safe under concurrent requests.
 */
function generate_document_number(PDO $db, string $table, string $column, string $prefix): string
{
    $db->beginTransaction();
    try {
        $stmt = $db->prepare("SELECT $column FROM $table WHERE $column LIKE :prefix ORDER BY id DESC LIMIT 1 FOR UPDATE");
        $stmt->execute(['prefix' => $prefix . '%']);
        $last = $stmt->fetchColumn();
        $nextNumber = 1;
        if ($last) {
            $numericPart = (int)substr($last, strlen($prefix));
            $nextNumber = $numericPart + 1;
        }
        $db->commit();
        return $prefix . str_pad((string)$nextNumber, 6, '0', STR_PAD_LEFT);
    } catch (Throwable $e) {
        $db->rollBack();
        throw $e;
    }
}

/** Redirect helper for non-AJAX flows. */
function redirect(string $path): void
{
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

/** Standard JSON response envelope for AJAX endpoints. */
function json_response(bool $success, string $message = '', array $data = [], int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}

/** Require specific POST fields; returns cleaned array or fails the request with 422. */
function require_fields(array $fields): array
{
    $out = [];
    $missing = [];
    foreach ($fields as $field) {
        $val = $_POST[$field] ?? null;
        if ($val === null || $val === '') {
            $missing[] = $field;
        }
        $out[$field] = is_string($val) ? clean($val) : $val;
    }
    if (!empty($missing)) {
        json_response(false, 'Missing required field(s): ' . implode(', ', $missing), [], 422);
    }
    return $out;
}
