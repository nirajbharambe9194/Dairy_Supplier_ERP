<?php
/**
 * Global application configuration.
 * Reads from environment variables when available, falls back to sane
 * local-development defaults. Never commit real production secrets here —
 * use a .env file (see .env.example) loaded by your host, or server env vars.
 */

if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}

// ---- Environment -----------------------------------------------------
define('APP_ENV', getenv('APP_ENV') ?: 'development'); // development | production
define('APP_DEBUG', APP_ENV !== 'production');
define('APP_URL', getenv('APP_URL') ?: 'http://localhost/dairy-erp');
define('APP_NAME', 'Dairy Supplier ERP');

// ---- Database ----------------------------------------------------------
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'dairy_erp');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// ---- Paths --------------------------------------------------------------
define('UPLOAD_PATH', APP_ROOT . '/uploads');
define('REPORT_PATH', APP_ROOT . '/reports');
define('LOG_PATH', APP_ROOT . '/storage_logs');

if (!is_dir(LOG_PATH)) {
    @mkdir(LOG_PATH, 0755, true);
}
if (!is_dir(UPLOAD_PATH)) {
    @mkdir(UPLOAD_PATH, 0755, true);
}

// ---- Error handling -------------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', LOG_PATH . '/php_errors.log');

set_exception_handler(function (Throwable $e) {
    error_log('[UNCAUGHT] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    try {
        require_once __DIR__ . '/database.php';
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare('INSERT INTO error_logs (message, file, line, trace) VALUES (?,?,?,?)');
        $stmt->execute([$e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString()]);
    } catch (Throwable $ignored) {
        // Logging must never itself fatal the request.
    }
    http_response_code(500);
    if (APP_DEBUG) {
        echo '<pre>' . htmlspecialchars($e->getMessage() . "\n" . $e->getTraceAsString()) . '</pre>';
    } else {
        echo 'Something went wrong. Please try again later.';
    }
});

// ---- Session ------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('dairy_erp_sid');
    session_start();

    // Basic session fixation guard: regenerate periodically.
    if (empty($_SESSION['_last_regen'])) {
        $_SESSION['_last_regen'] = time();
    } elseif (time() - $_SESSION['_last_regen'] > 900) {
        session_regenerate_id(true);
        $_SESSION['_last_regen'] = time();
    }
}

// ---- Timezone -------------------------------------------------------------
date_default_timezone_set('Asia/Kolkata');

// ---- Autoload -------------------------------------------------------------
spl_autoload_register(function ($class) {
    $dirs = ['models', 'controllers', 'helpers'];
    foreach ($dirs as $dir) {
        $file = APP_ROOT . "/$dir/$class.php";
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Composer-installed libraries (DomPDF, PhpSpreadsheet) are optional; the app
// degrades gracefully (see BillingController::downloadPdf) if not installed yet.
if (file_exists(APP_ROOT . '/vendor/autoload.php')) {
    require_once APP_ROOT . '/vendor/autoload.php';
}

require_once APP_ROOT . '/helpers/functions.php';
require_once APP_ROOT . '/includes/csrf.php';
require_once APP_ROOT . '/includes/auth_middleware.php';
