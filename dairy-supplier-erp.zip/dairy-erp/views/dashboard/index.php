<?php
$pageTitle = 'Dashboard';
$activeMenu = 'dashboard';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="row g-3 mb-2">
  <?php
  $cards = [
    ['Total Companies', $data['total_companies'], 'fa-industry', '#2f6f4f'],
    ['Total Distributors', $data['total_distributors'], 'fa-truck-field', '#3b6fb6'],
    ['Total Products', $data['total_products'], 'fa-jar', '#b6893b'],
    ['Inventory Value', format_money($data['inventory_value']), 'fa-warehouse', '#7a3bb6'],
  ];
  foreach ($cards as [$label, $value, $icon, $color]): ?>
    <div class="col-6 col-lg-3">
      <div class="card kpi-card p-3 d-flex flex-row align-items-center gap-3">
        <div class="kpi-icon" style="background: <?= $color ?>"><i class="fa-solid <?= $icon ?>"></i></div>
        <div>
          <div class="text-muted small"><?= e($label) ?></div>
          <div class="fs-5 fw-semibold"><?= is_numeric($value) ? number_format((float)$value) : $value ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-2">
  <?php
  $cards2 = [
    ["Today's Purchases", format_money($data['todays_purchases']), 'fa-cart-shopping', '#c0392b'],
    ["Today's Deliveries", $data['todays_deliveries'], 'fa-truck-fast', '#16a085'],
    ["Today's Sales", format_money($data['todays_sales']), 'fa-file-invoice-dollar', '#2980b9'],
    ['Monthly Revenue', format_money($data['monthly_revenue']), 'fa-sack-dollar', '#27ae60'],
  ];
  foreach ($cards2 as [$label, $value, $icon, $color]): ?>
    <div class="col-6 col-lg-3">
      <div class="card kpi-card p-3 d-flex flex-row align-items-center gap-3">
        <div class="kpi-icon" style="background: <?= $color ?>"><i class="fa-solid <?= $icon ?>"></i></div>
        <div>
          <div class="text-muted small"><?= e($label) ?></div>
          <div class="fs-5 fw-semibold"><?= is_numeric($value) ? number_format((float)$value) : $value ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-2">
  <?php
  $cards3 = [
    ['Pending Company Payments', format_money($data['pending_company_payments']), 'fa-hand-holding-dollar', '#d35400'],
    ['Pending Distributor Payments', format_money($data['pending_distributor_payments']), 'fa-money-bill-wave', '#8e44ad'],
    ['Gross Profit (Month)', format_money($data['gross_profit']), 'fa-chart-simple', '#27ae60'],
    ['Net Profit (Month)', format_money($data['net_profit']), 'fa-scale-balanced', '#2c3e50'],
  ];
  foreach ($cards3 as [$label, $value, $icon, $color]): ?>
    <div class="col-6 col-lg-3">
      <div class="card kpi-card p-3 d-flex flex-row align-items-center gap-3">
        <div class="kpi-icon" style="background: <?= $color ?>"><i class="fa-solid <?= $icon ?>"></i></div>
        <div>
          <div class="text-muted small"><?= e($label) ?></div>
          <div class="fs-5 fw-semibold"><?= is_numeric($value) ? number_format((float)$value) : $value ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if (!empty($data['low_stock']) || !empty($data['expiring'])): ?>
<div class="row g-3 mb-2">
  <?php if (!empty($data['low_stock'])): ?>
  <div class="col-lg-6">
    <div class="card p-3">
      <h6 class="mb-2 text-danger"><i class="fa-solid fa-triangle-exclamation me-1"></i>Low Stock Alerts</h6>
      <ul class="list-group list-group-flush">
        <?php foreach (array_slice($data['low_stock'], 0, 5) as $p): ?>
          <li class="list-group-item d-flex justify-content-between px-0">
            <?= e($p['product_name']) ?>
            <span class="badge bg-danger"><?= (float)$p['current_stock'] ?> <?= e($p['unit']) ?> left</span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <?php endif; ?>
  <?php if (!empty($data['expiring'])): ?>
  <div class="col-lg-6">
    <div class="card p-3">
      <h6 class="mb-2 text-warning"><i class="fa-solid fa-hourglass-half me-1"></i>Expiring Soon</h6>
      <ul class="list-group list-group-flush">
        <?php foreach (array_slice($data['expiring'], 0, 5) as $p): ?>
          <li class="list-group-item d-flex justify-content-between px-0">
            <?= e($p['product_name']) ?> (Batch <?= e($p['batch_number']) ?>)
            <span class="badge bg-warning text-dark">Exp: <?= format_date($p['expiry_date']) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="row g-3 mb-2">
  <div class="col-lg-6">
    <div class="card p-3">
      <h6 class="mb-2">Monthly Sales vs Purchases</h6>
      <canvas id="salesPurchaseChart" height="180"></canvas>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card p-3">
      <h6 class="mb-2">Top Products (Last 30 Days)</h6>
      <canvas id="productSalesChart" height="180"></canvas>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card p-3">
      <h6 class="mb-2">Recent Purchases</h6>
      <?php foreach ($data['recent_purchases'] as $p): ?>
        <div class="d-flex justify-content-between border-bottom py-1 small">
          <span><?= e($p['purchase_no']) ?> · <?= e($p['company_name']) ?></span>
          <span><?= format_money($p['total_amount']) ?></span>
        </div>
      <?php endforeach; ?>
      <?php if (empty($data['recent_purchases'])): ?><p class="text-muted small mb-0">No purchases yet.</p><?php endif; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card p-3">
      <h6 class="mb-2">Recent Deliveries</h6>
      <?php foreach ($data['recent_deliveries'] as $d): ?>
        <div class="d-flex justify-content-between border-bottom py-1 small">
          <span><?= e($d['delivery_no']) ?> · <?= e($d['distributor_name']) ?></span>
          <span><?= format_money($d['total_amount']) ?></span>
        </div>
      <?php endforeach; ?>
      <?php if (empty($data['recent_deliveries'])): ?><p class="text-muted small mb-0">No deliveries yet.</p><?php endif; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card p-3">
      <h6 class="mb-2">Recent Payments</h6>
      <?php foreach ($data['recent_payments'] as $p): ?>
        <div class="d-flex justify-content-between border-bottom py-1 small">
          <span><?= e($p['party_type']) ?> · <?= e($p['party_name']) ?></span>
          <span><?= format_money($p['amount']) ?></span>
        </div>
      <?php endforeach; ?>
      <?php if (empty($data['recent_payments'])): ?><p class="text-muted small mb-0">No payments yet.</p><?php endif; ?>
    </div>
  </div>
</div>

<script>
const salesData = <?= json_encode($data['sales_chart']) ?>;
const purchaseData = <?= json_encode($data['purchase_chart']) ?>;
const productData = <?= json_encode($data['product_sales_chart']) ?>;

const months = [...new Set([...salesData.map(r => r.ym), ...purchaseData.map(r => r.ym)])].sort();
new Chart(document.getElementById('salesPurchaseChart'), {
  type: 'line',
  data: {
    labels: months,
    datasets: [
      { label: 'Sales', data: months.map(m => (salesData.find(r => r.ym === m) || {}).total || 0), borderColor: '#2f6f4f', tension: .3 },
      { label: 'Purchases', data: months.map(m => (purchaseData.find(r => r.ym === m) || {}).total || 0), borderColor: '#c0392b', tension: .3 },
    ]
  },
  options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});

new Chart(document.getElementById('productSalesChart'), {
  type: 'bar',
  data: {
    labels: productData.map(p => p.product_name),
    datasets: [{ label: 'Revenue', data: productData.map(p => p.amount), backgroundColor: '#3b6fb6' }]
  },
  options: { responsive: true, plugins: { legend: { display: false } } }
});
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
