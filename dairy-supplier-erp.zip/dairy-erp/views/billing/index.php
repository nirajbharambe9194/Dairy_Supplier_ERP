<?php
$pageTitle = 'Billing / Invoices';
$activeMenu = 'billing';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Billing / Invoices</h5>
</div>

<div class="card p-3 mb-3">
  <div class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label small">From</label><input type="date" id="f_from" class="form-control form-control-sm"></div>
    <div class="col-md-3"><label class="form-label small">To</label><input type="date" id="f_to" class="form-control form-control-sm"></div>
    <div class="col-md-3">
      <label class="form-label small">Distributor</label>
      <select id="f_distributor" class="form-select form-select-sm">
        <option value="">All Distributors</option>
        <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <button class="btn btn-outline-primary btn-sm w-100" onclick="loadInvoices()"><i class="fa-solid fa-filter me-1"></i>Filter</button>
    </div>
  </div>
</div>

<div class="card p-3">
  <table id="invoicesTable" class="table table-hover align-middle w-100">
    <thead><tr><th>Invoice #</th><th>Date</th><th>Distributor</th><th>Total</th><th>Received</th><th>Outstanding</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<p class="text-muted small mt-2">
  Invoices are generated automatically from a delivery when "Auto-generate invoice" is checked on the Deliveries page.
</p>

<script>
let invoicesTable;
function loadInvoices() {
  apiCall('billing', 'list', { from: $('#f_from').val(), to: $('#f_to').val(), distributor_id: $('#f_distributor').val() }, 'GET').done(function (res) {
    if (invoicesTable) invoicesTable.destroy();
    invoicesTable = $('#invoicesTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'invoice_no' }, { data: 'invoice_date' }, { data: 'distributor_name' },
        { data: 'total_amount', render: d => money(d) },
        { data: 'payment_received', render: d => money(d) },
        { data: 'outstanding_balance', render: d => `<span class="${d > 0 ? 'text-danger' : 'text-success'}">${money(d)}</span>` },
        { data: 'status', render: s => `<span class="badge bg-${s === 'paid' ? 'success' : (s === 'partial' ? 'warning' : 'danger')}">${s}</span>` },
        {
          data: null, orderable: false, render: r => `
            <a class="btn btn-sm btn-outline-secondary" target="_blank" href="${window.APP_URL}/index.php?page=invoice_print&id=${r.id}" title="Print"><i class="fa-solid fa-print"></i></a>
            <a class="btn btn-sm btn-outline-primary" target="_blank" href="${window.APP_URL}/index.php?page=invoice_pdf&id=${r.id}" title="Download PDF"><i class="fa-solid fa-file-pdf"></i></a>
          `
        },
      ]
    });
  });
}
$(loadInvoices);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
