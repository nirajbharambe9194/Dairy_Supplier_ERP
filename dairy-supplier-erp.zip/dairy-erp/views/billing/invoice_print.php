<?php
/**
 * Self-contained print view (no app sidebar/nav) so it doubles as clean
 * DomPDF source HTML. Expects $invoice (with items + distributor) in scope.
 */
if (!defined('APP_ROOT')) { exit('Direct access not permitted.'); }
$companyName = get_setting('company_name', APP_NAME);
$companyAddress = get_setting('company_address', '');
$companyPhone = get_setting('company_phone', '');
$companyGst = get_setting('company_gst', '');
$dist = $invoice['distributor'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Invoice <?= e($invoice['invoice_no']) ?></title>
<style>
  body { font-family: 'DejaVu Sans', Arial, sans-serif; color: #222; font-size: 13px; margin: 30px; }
  .header { display: flex; justify-content: space-between; border-bottom: 2px solid #2f6f4f; padding-bottom: 10px; margin-bottom: 20px; }
  .header h2 { margin: 0; color: #2f6f4f; }
  table { width: 100%; border-collapse: collapse; margin-top: 15px; }
  th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
  th { background: #f2f5f3; }
  .text-end { text-align: right; }
  .totals td { border: none; padding: 3px 8px; }
  .no-print { margin-bottom: 15px; }
  @media print { .no-print { display: none; } }
</style>
</head>
<body>

<div class="no-print">
  <button onclick="window.print()">🖨 Print Invoice</button>
  <a href="<?= APP_URL ?>/index.php?page=invoice_pdf&id=<?= (int)$invoice['id'] ?>">⬇ Download PDF</a>
  <a href="mailto:<?= e($dist['email'] ?? '') ?>?subject=Invoice <?= e($invoice['invoice_no']) ?>">✉ Email Invoice</a>
</div>

<div class="header">
  <div>
    <h2><?= e($companyName) ?></h2>
    <div><?= e($companyAddress) ?></div>
    <div>Phone: <?= e($companyPhone) ?> | GSTIN: <?= e($companyGst) ?></div>
  </div>
  <div class="text-end">
    <h3>INVOICE</h3>
    <div><b>No:</b> <?= e($invoice['invoice_no']) ?></div>
    <div><b>Date:</b> <?= format_date($invoice['invoice_date']) ?></div>
  </div>
</div>

<div>
  <b>Bill To:</b><br>
  <?= e($dist['distributor_name']) ?> (<?= e($dist['shop_name']) ?>)<br>
  <?= e($dist['address']) ?>, <?= e($dist['city']) ?>, <?= e($dist['state']) ?><br>
  GSTIN: <?= e($dist['gst_number']) ?> | Phone: <?= e($dist['phone']) ?>
</div>

<table>
  <thead>
    <tr><th>#</th><th>Product</th><th>Qty</th><th>Unit</th><th>Rate</th><th>GST %</th><th class="text-end">Line Total</th></tr>
  </thead>
  <tbody>
    <?php foreach ($invoice['items'] as $i => $item): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= e($item['product_name']) ?></td>
        <td><?= (float)$item['quantity'] ?></td>
        <td><?= e($item['unit']) ?></td>
        <td><?= format_money($item['rate']) ?></td>
        <td><?= (float)$item['gst_percent'] ?>%</td>
        <td class="text-end"><?= format_money($item['line_total']) ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<table class="totals" style="width: 320px; margin-left: auto;">
  <tr><td>Subtotal</td><td class="text-end"><?= format_money($invoice['subtotal']) ?></td></tr>
  <tr><td>GST</td><td class="text-end"><?= format_money($invoice['gst_amount']) ?></td></tr>
  <tr><td><b>Total</b></td><td class="text-end"><b><?= format_money($invoice['total_amount']) ?></b></td></tr>
  <tr><td>Previous Balance</td><td class="text-end"><?= format_money($invoice['previous_balance']) ?></td></tr>
  <tr><td>Payment Received</td><td class="text-end"><?= format_money($invoice['payment_received']) ?></td></tr>
  <tr><td><b>Outstanding Balance</b></td><td class="text-end"><b><?= format_money($invoice['outstanding_balance']) ?></b></td></tr>
</table>

<p style="margin-top:40px; font-size: 11px; color: #777;">This is a computer-generated invoice from <?= e($companyName) ?>.</p>

</body>
</html>
