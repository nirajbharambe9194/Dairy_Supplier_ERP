<?php
$pageTitle = 'Payments';
$activeMenu = 'payments';
require APP_ROOT . '/views/layouts/header.php';
?>

<ul class="nav nav-tabs mb-3">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#companyPayTab">Company Payments (Paid)</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#distPayTab">Distributor Payments (Received)</button></li>
</ul>

<div class="tab-content">
  <div class="tab-pane fade show active" id="companyPayTab">
    <div class="d-flex justify-content-between mb-2">
      <h6>Payments to Companies</h6>
      <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#cpModal"><i class="fa-solid fa-plus me-1"></i>Record Payment</button>
    </div>
    <div class="card p-3">
      <table id="cpTable" class="table table-hover w-100">
        <thead><tr><th>Date</th><th>Company</th><th>Method</th><th>Reference</th><th>Amount</th><th>Balance After</th></tr></thead>
        <tbody></tbody>
      </table>
    </div>
  </div>

  <div class="tab-pane fade" id="distPayTab">
    <div class="d-flex justify-content-between mb-2">
      <h6>Payments from Distributors</h6>
      <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#dpModal"><i class="fa-solid fa-plus me-1"></i>Record Payment</button>
    </div>
    <div class="card p-3">
      <table id="dpTable" class="table table-hover w-100">
        <thead><tr><th>Date</th><th>Distributor</th><th>Invoice #</th><th>Method</th><th>Amount</th><th>Balance After</th></tr></thead>
        <tbody></tbody>
      </table>
    </div>
  </div>
</div>

<!-- Company Payment Modal -->
<div class="modal fade" id="cpModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="cpForm">
        <div class="modal-header"><h5 class="modal-title">Record Company Payment</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
          <div class="col-12">
            <label class="form-label">Company *</label>
            <select class="form-select" name="company_id" required>
              <option value="">Select</option>
              <?php foreach ($companies as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['company_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label">Payment Date</label><input type="date" class="form-control" name="payment_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-6"><label class="form-label">Amount *</label><input type="number" step="0.01" class="form-control" name="amount" required></div>
          <div class="col-md-6">
            <label class="form-label">Payment Method</label>
            <select class="form-select" name="payment_method">
              <option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option>
              <option value="cheque">Cheque</option><option value="upi">UPI</option><option value="other">Other</option>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label">Transaction Ref</label><input class="form-control" name="transaction_reference"></div>
          <div class="col-12"><label class="form-label">Invoice # (optional)</label><input class="form-control" name="invoice_no"></div>
          <div class="col-12"><label class="form-label">Remarks</label><input class="form-control" name="remarks"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Payment</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Distributor Payment Modal -->
<div class="modal fade" id="dpModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="dpForm">
        <div class="modal-header"><h5 class="modal-title">Record Distributor Payment</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-3">
          <div class="col-12">
            <label class="form-label">Distributor *</label>
            <select class="form-select" name="distributor_id" required>
              <option value="">Select</option>
              <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label">Payment Date</label><input type="date" class="form-control" name="payment_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-6"><label class="form-label">Amount *</label><input type="number" step="0.01" class="form-control" name="amount" required></div>
          <div class="col-md-6">
            <label class="form-label">Payment Method</label>
            <select class="form-select" name="payment_method">
              <option value="cash">Cash</option><option value="bank_transfer">Bank Transfer</option>
              <option value="cheque">Cheque</option><option value="upi">UPI</option><option value="other">Other</option>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label">Invoice # (optional)</label><input class="form-control" name="invoice_no" placeholder="Applies payment to this invoice"></div>
          <div class="col-12"><label class="form-label">Transaction Ref</label><input class="form-control" name="transaction_reference"></div>
          <div class="col-12"><label class="form-label">Remarks</label><input class="form-control" name="remarks"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Payment</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let cpTable, dpTable;

function loadCompanyPayments() {
  apiCall('payments', 'list_company', {}, 'GET').done(function (res) {
    if (cpTable) cpTable.destroy();
    cpTable = $('#cpTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'payment_date' }, { data: 'company_name' }, { data: 'payment_method' },
        { data: 'transaction_reference', defaultContent: '-' }, { data: 'amount', render: d => money(d) },
        { data: 'outstanding_balance', render: d => money(d) },
      ]
    });
  });
}

function loadDistPayments() {
  apiCall('payments', 'list_distributor', {}, 'GET').done(function (res) {
    if (dpTable) dpTable.destroy();
    dpTable = $('#dpTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'payment_date' }, { data: 'distributor_name' }, { data: 'invoice_no', defaultContent: '-' },
        { data: 'payment_method' }, { data: 'amount', render: d => money(d) },
        { data: 'remaining_balance', render: d => money(d) },
      ]
    });
  });
}

$('#cpForm').on('submit', function (e) {
  e.preventDefault();
  apiCall('payments', 'store_company', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('cpModal')).hide(); loadCompanyPayments(); }
    });
});

$('#dpForm').on('submit', function (e) {
  e.preventDefault();
  apiCall('payments', 'store_distributor', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('dpModal')).hide(); loadDistPayments(); }
    });
});

$(function () { loadCompanyPayments(); loadDistPayments(); });
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
