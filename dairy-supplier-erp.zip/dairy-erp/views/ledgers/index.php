<?php
$pageTitle = 'Ledgers';
$activeMenu = 'ledgers';
require APP_ROOT . '/views/layouts/header.php';
?>

<ul class="nav nav-tabs mb-3">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#companyLedgerTab">Company Ledgers</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#distLedgerTab">Distributor Ledgers</button></li>
</ul>

<div class="tab-content">
  <div class="tab-pane fade show active" id="companyLedgerTab">
    <div class="card p-3 mb-3">
      <div class="row g-2 align-items-end">
        <div class="col-md-6">
          <label class="form-label small">Select Company</label>
          <select id="lc_company" class="form-select">
            <option value="">-- Select --</option>
            <?php foreach ($companies as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['company_name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3"><button class="btn btn-primary" onclick="loadCompanyLedger()">View Ledger</button></div>
        <div class="col-md-3 text-end" id="lc_outstanding"></div>
      </div>
    </div>
    <div class="card p-3">
      <table class="table table-sm table-striped" id="lc_table">
        <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
        <tbody></tbody>
      </table>
    </div>
  </div>

  <div class="tab-pane fade" id="distLedgerTab">
    <div class="card p-3 mb-3">
      <div class="row g-2 align-items-end">
        <div class="col-md-6">
          <label class="form-label small">Select Distributor</label>
          <select id="ld_distributor" class="form-select">
            <option value="">-- Select --</option>
            <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3"><button class="btn btn-primary" onclick="loadDistLedger()">View Ledger</button></div>
        <div class="col-md-3 text-end" id="ld_outstanding"></div>
      </div>
    </div>
    <div class="card p-3">
      <table class="table table-sm table-striped" id="ld_table">
        <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
        <tbody></tbody>
      </table>
    </div>
  </div>
</div>

<script>
function ledgerRows(rows) {
  return rows.map(r => `
    <tr>
      <td>${r.txn_date}</td>
      <td><span class="badge bg-light text-dark">${r.txn_type.replace('_',' ')}</span></td>
      <td>${r.reference_no || ''}</td>
      <td class="text-danger">${r.debit > 0 ? money(r.debit) : ''}</td>
      <td class="text-success">${r.credit > 0 ? money(r.credit) : ''}</td>
      <td class="fw-semibold">${money(r.running_balance)}</td>
    </tr>`).join('') || '<tr><td colspan="6" class="text-center text-muted">No transactions yet.</td></tr>';
}

function loadCompanyLedger() {
  const id = $('#lc_company').val();
  if (!id) return;
  apiCall('ledgers', 'company', { id }, 'GET').done(function (res) {
    $('#lc_table tbody').html(ledgerRows(res.data));
    $('#lc_outstanding').html(`<span class="badge bg-${res.outstanding > 0 ? 'danger' : 'success'} fs-6">Outstanding: ${money(res.outstanding)}</span>`);
  });
}

function loadDistLedger() {
  const id = $('#ld_distributor').val();
  if (!id) return;
  apiCall('ledgers', 'distributor', { id }, 'GET').done(function (res) {
    $('#ld_table tbody').html(ledgerRows(res.data));
    $('#ld_outstanding').html(`<span class="badge bg-${res.outstanding > 0 ? 'danger' : 'success'} fs-6">Outstanding: ${money(res.outstanding)}</span>`);
  });
}
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
