<?php
$pageTitle = 'Products';
$activeMenu = 'products';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Products</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#productModal" onclick="resetProductForm()">
    <i class="fa-solid fa-plus me-1"></i>Add Product
  </button>
</div>

<div class="card p-3">
  <table id="productsTable" class="table table-hover align-middle w-100">
    <thead>
      <tr><th>Code</th><th>Name</th><th>Category</th><th>Unit</th><th>Purchase Price</th><th>Selling Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<div class="modal fade" id="productModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form id="productForm">
        <div class="modal-header">
          <h5 class="modal-title" id="productModalTitle">Add Product</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
          <input type="hidden" name="id" id="p_id">
          <div class="col-md-6">
            <label class="form-label">Product Name *</label>
            <input class="form-control" name="product_name" id="p_product_name" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Category</label>
            <select class="form-select" name="category_id" id="p_category_id">
              <option value="">-- None --</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>"><?= e($cat['category_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Brand</label>
            <input class="form-control" name="brand" id="p_brand">
          </div>
          <div class="col-md-4">
            <label class="form-label">Unit *</label>
            <input class="form-control" name="unit" id="p_unit" placeholder="Ltr / Kg / Pcs" required>
          </div>
          <div class="col-md-4">
            <label class="form-label">Barcode</label>
            <input class="form-control" name="barcode" id="p_barcode">
          </div>
          <div class="col-md-4">
            <label class="form-label">Purchase Price</label>
            <input type="number" step="0.01" class="form-control" name="purchase_price" id="p_purchase_price" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">Selling Price</label>
            <input type="number" step="0.01" class="form-control" name="selling_price" id="p_selling_price" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">GST %</label>
            <input type="number" step="0.01" class="form-control" name="gst_percent" id="p_gst_percent" value="0">
          </div>
          <div class="col-md-4" id="openingStockWrap">
            <label class="form-label">Opening Stock</label>
            <input type="number" step="0.001" class="form-control" name="current_stock" id="p_current_stock" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">Minimum Stock</label>
            <input type="number" step="0.001" class="form-control" name="minimum_stock" id="p_minimum_stock" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">Status</label>
            <select class="form-select" name="status" id="p_status">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Product</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Stock Adjustment Modal -->
<div class="modal fade" id="adjustModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="adjustForm">
        <div class="modal-header">
          <h5 class="modal-title">Adjust Stock</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="product_id" id="adj_product_id">
          <div class="mb-3">
            <label class="form-label">Direction</label>
            <select class="form-select" name="direction" id="adj_direction">
              <option value="increase">Increase (found extra stock)</option>
              <option value="decrease">Decrease (damage / loss)</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Quantity</label>
            <input type="number" step="0.001" class="form-control" name="quantity" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Remarks</label>
            <input class="form-control" name="remarks" placeholder="Reason for adjustment">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-warning">Adjust</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let productsTable;
const isAdminP = <?= json_encode(current_role() === 'admin') ?>;

function resetProductForm() {
  $('#productForm')[0].reset();
  $('#p_id').val('');
  $('#openingStockWrap').show();
  $('#productModalTitle').text('Add Product');
}

function loadProducts() {
  apiCall('products', 'list', {}, 'GET').done(function (res) {
    if (productsTable) productsTable.destroy();
    productsTable = $('#productsTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'product_code' },
        { data: 'product_name' },
        { data: 'category_name', defaultContent: '-' },
        { data: 'unit' },
        { data: 'purchase_price', render: d => money(d) },
        { data: 'selling_price', render: d => money(d) },
        { data: null, render: r => `${Number(r.current_stock)} ${r.unit}` + (Number(r.current_stock) <= Number(r.minimum_stock) ? ' <span class="badge bg-danger">Low</span>' : '') },
        { data: 'status', render: s => `<span class="badge bg-${s === 'active' ? 'success' : 'secondary'}">${s}</span>` },
        {
          data: null, orderable: false, render: (row) => `
            <button class="btn btn-sm btn-outline-secondary" onclick='editProduct(${JSON.stringify(row)})'><i class="fa-solid fa-pen"></i></button>
            <button class="btn btn-sm btn-outline-warning" onclick="openAdjust(${row.id})"><i class="fa-solid fa-scale-unbalanced"></i></button>
            ${isAdminP ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${row.id})"><i class="fa-solid fa-trash"></i></button>` : ''}
          `
        },
      ]
    });
  });
}

function editProduct(row) {
  $('#productModalTitle').text('Edit Product');
  $('#p_id').val(row.id);
  $('#openingStockWrap').hide(); // stock is managed via purchases/adjustments once created
  ['product_name','category_id','brand','unit','barcode','purchase_price','selling_price','gst_percent','minimum_stock','status']
    .forEach(f => $('#p_' + f).val(row[f]));
  new bootstrap.Modal(document.getElementById('productModal')).show();
}

function deleteProduct(id) {
  if (!confirm('Delete this product?')) return;
  apiCall('products', 'delete', { id }).done(function (res) {
    showToast(res.message, res.success ? 'success' : 'danger');
    if (res.success) loadProducts();
  });
}

function openAdjust(productId) {
  $('#adjustForm')[0].reset();
  $('#adj_product_id').val(productId);
  new bootstrap.Modal(document.getElementById('adjustModal')).show();
}

$('#adjustForm').on('submit', function (e) {
  e.preventDefault();
  apiCall('products', 'adjust_stock', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('adjustModal')).hide(); loadProducts(); }
    });
});

$('#productForm').on('submit', function (e) {
  e.preventDefault();
  const id = $('#p_id').val();
  apiCall('products', id ? 'update' : 'store', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('productModal')).hide(); loadProducts(); }
    });
});

$(loadProducts);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
