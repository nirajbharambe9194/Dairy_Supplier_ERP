<?php
$pageTitle = 'Daily Demand';
$activeMenu = 'daily_demand';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <h5 class="mb-0">Daily Demand Planning</h5>
  <div class="d-flex gap-2 align-items-end">
    <div><label class="form-label small mb-0">Date</label><input type="date" id="dd_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>"></div>
    <div>
      <label class="form-label small mb-0">Distributor</label>
      <select id="dd_distributor" class="form-select form-select-sm">
        <option value="">All Distributors</option>
        <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <button class="btn btn-outline-primary btn-sm" onclick="loadDemand()"><i class="fa-solid fa-rotate me-1"></i>Load</button>
    <button class="btn btn-outline-warning btn-sm" onclick="copyPrevious()"><i class="fa-solid fa-copy me-1"></i>Copy Previous Day</button>
    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addDemandModal"><i class="fa-solid fa-plus me-1"></i>Add Line</button>
  </div>
</div>

<div class="card p-3">
  <table class="table table-sm table-hover" id="demandTable">
    <thead><tr><th>Distributor</th><th>Product</th><th>Morning</th><th>Evening</th><th>Total</th><th>Rate</th><th>Amount</th><th></th></tr></thead>
    <tbody></tbody>
    <tfoot><tr class="fw-bold"><td colspan="6" class="text-end">Grand Total</td><td id="dd_grand_total">0.00</td><td></td></tr></tfoot>
  </table>
  <p class="text-muted small mb-0">Edit quantities directly in the grid, then click <b>Save Changes</b>.</p>
  <button class="btn btn-success mt-2" style="width:fit-content" onclick="saveDemand()"><i class="fa-solid fa-floppy-disk me-1"></i>Save Changes</button>
</div>

<div class="modal fade" id="addDemandModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Add Demand Line</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body row g-3">
        <div class="col-12">
          <label class="form-label">Distributor</label>
          <select class="form-select" id="new_distributor_id">
            <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-12">
          <label class="form-label">Product</label>
          <select class="form-select" id="new_product_id">
            <?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>" data-price="<?= $p['selling_price'] ?>"><?= e($p['product_name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-4"><label class="form-label">Morning</label><input type="number" step="0.001" class="form-control" id="new_morning" value="0"></div>
        <div class="col-4"><label class="form-label">Evening</label><input type="number" step="0.001" class="form-control" id="new_evening" value="0"></div>
        <div class="col-4"><label class="form-label">Rate</label><input type="number" step="0.01" class="form-control" id="new_rate" value="0"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-success" onclick="addDemandLine()">Add</button>
      </div>
    </div>
  </div>
</div>

<script>
let dirtyLines = {};

function rowKey(distId, prodId) { return distId + '_' + prodId; }

function loadDemand() {
  apiCall('daily_demand', 'list', { date: $('#dd_date').val(), distributor_id: $('#dd_distributor').val() }, 'GET').done(function (res) {
    const tbody = $('#demandTable tbody').empty();
    let grand = 0;
    (res.data || []).forEach(row => {
      grand += Number(row.amount);
      tbody.append(`
        <tr data-id="${row.id}" data-dist="${row.distributor_id}" data-prod="${row.product_id}">
          <td>${row.distributor_name}</td>
          <td>${row.product_name}</td>
          <td><input type="number" step="0.001" class="form-control form-control-sm morning" value="${row.morning_qty}"></td>
          <td><input type="number" step="0.001" class="form-control form-control-sm evening" value="${row.evening_qty}"></td>
          <td class="total">${row.total_qty}</td>
          <td><input type="number" step="0.01" class="form-control form-control-sm rate" value="${row.rate}"></td>
          <td class="amount">${money(row.amount)}</td>
          <td><button class="btn btn-sm btn-outline-danger" onclick="removeDemandLine(${row.id}, this)"><i class="fa-solid fa-xmark"></i></button></td>
        </tr>
      `);
    });
    $('#dd_grand_total').text(money(grand));
  });
}

$(document).on('input', '.morning, .evening, .rate', function () {
  const tr = $(this).closest('tr');
  const m = parseFloat(tr.find('.morning').val()) || 0;
  const ev = parseFloat(tr.find('.evening').val()) || 0;
  const rate = parseFloat(tr.find('.rate').val()) || 0;
  const total = m + ev;
  tr.find('.total').text(total);
  tr.find('.amount').text(money(total * rate));
  let grand = 0;
  $('#demandTable tbody tr').each(function () {
    grand += (parseFloat($(this).find('.total').text()) || 0) * (parseFloat($(this).find('.rate').val()) || 0);
  });
  $('#dd_grand_total').text(money(grand));
});

function addDemandLine() {
  const distId = $('#new_distributor_id').val();
  const distName = $('#new_distributor_id option:selected').text();
  const prodId = $('#new_product_id').val();
  const prodName = $('#new_product_id option:selected').text();
  const morning = $('#new_morning').val() || 0;
  const evening = $('#new_evening').val() || 0;
  const rate = $('#new_rate').val() || 0;
  const total = Number(morning) + Number(evening);
  $('#demandTable tbody').append(`
    <tr data-id="0" data-dist="${distId}" data-prod="${prodId}">
      <td>${distName}</td><td>${prodName}</td>
      <td><input type="number" step="0.001" class="form-control form-control-sm morning" value="${morning}"></td>
      <td><input type="number" step="0.001" class="form-control form-control-sm evening" value="${evening}"></td>
      <td class="total">${total}</td>
      <td><input type="number" step="0.01" class="form-control form-control-sm rate" value="${rate}"></td>
      <td class="amount">${money(total * rate)}</td>
      <td><button class="btn btn-sm btn-outline-danger" onclick="$(this).closest('tr').remove()"><i class="fa-solid fa-xmark"></i></button></td>
    </tr>
  `);
  bootstrap.Modal.getInstance(document.getElementById('addDemandModal')).hide();
}

function removeDemandLine(id, btn) {
  if (id > 0 && !confirm('Remove this line permanently?')) return;
  if (id > 0) {
    apiCall('daily_demand', 'delete_line', { id }).done(() => $(btn).closest('tr').remove());
  } else {
    $(btn).closest('tr').remove();
  }
}

function saveDemand() {
  const lines = [];
  $('#demandTable tbody tr').each(function () {
    lines.push({
      distributor_id: $(this).data('dist'),
      product_id: $(this).data('prod'),
      morning_qty: $(this).find('.morning').val() || 0,
      evening_qty: $(this).find('.evening').val() || 0,
      rate: $(this).find('.rate').val() || 0,
    });
  });
  if (lines.length === 0) { showToast('Nothing to save.', 'warning'); return; }
  apiCall('daily_demand', 'save', { demand_date: $('#dd_date').val(), lines: JSON.stringify(lines) })
    .done(function (res) { showToast(res.message, res.success ? 'success' : 'danger'); if (res.success) loadDemand(); });
}

function copyPrevious() {
  apiCall('daily_demand', 'copy_previous', { demand_date: $('#dd_date').val(), distributor_id: $('#dd_distributor').val() })
    .done(function (res) { showToast(res.message, res.success ? 'success' : 'danger'); if (res.success) loadDemand(); });
}

$(loadDemand);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
