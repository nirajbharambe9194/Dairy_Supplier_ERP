<?php
$pageTitle = 'Purchase Returns';
$activeMenu = 'purchase_returns';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Purchase Returns (to Companies)</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#returnModal" onclick="$('#returnForm')[0].reset()">
    <i class="fa-solid fa-plus me-1"></i>New Return
  </button>
</div>

<div class="card p-3">
  <table id="returnsTable" class="table table-hover align-middle w-100">
    <thead><tr><th>Return #</th><th>Date</th><th>Company</th><th>Product</th><th>Qty</th><th>Amount</th><th>Reason</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<div class="modal fade" id="returnModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="returnForm">
        <div class="modal-header">
          <h5 class="modal-title">New Purchase Return</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
          <div class="col-12">
            <label class="form-label">Company *</label>
            <select class="form-select" name="company_id" required>
              <option value="">Select</option>
              <?php foreach ($companies as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['company_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-12">
            <label class="form-label">Product *</label>
            <select class="form-select" name="product_id" required>
              <option value="">Select</option>
              <?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['product_name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6"><label class="form-label">Return Date</label><input type="date" class="form-control" name="return_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="col-md-6"><label class="form-label">Batch #</label><input class="form-control" name="batch_number"></div>
          <div class="col-md-6"><label class="form-label">Quantity *</label><input type="number" step="0.001" class="form-control" name="quantity" required></div>
          <div class="col-md-6"><label class="form-label">Rate *</label><input type="number" step="0.01" class="form-control" name="rate" required></div>
          <div class="col-md-6"><label class="form-label">Credit Note #</label><input class="form-control" name="credit_note_no"></div>
          <div class="col-md-6"><label class="form-label">Reason</label><input class="form-control" name="reason"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Return</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let returnsTable;
function loadReturns() {
  apiCall('purchase_returns', 'list', {}, 'GET').done(function (res) {
    if (returnsTable) returnsTable.destroy();
    returnsTable = $('#returnsTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'return_no' }, { data: 'return_date' }, { data: 'company_name' },
        { data: 'product_name' }, { data: 'quantity' }, { data: 'amount', render: d => money(d) }, { data: 'reason', defaultContent: '-' },
      ]
    });
  });
}
$('#returnForm').on('submit', function (e) {
  e.preventDefault();
  apiCall('purchase_returns', 'store', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('returnModal')).hide(); loadReturns(); }
    });
});
$(loadReturns);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
