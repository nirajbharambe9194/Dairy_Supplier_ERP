<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>404 Not Found</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css"></head>
<body class="d-flex align-items-center justify-content-center vh-100 bg-light">
<div class="text-center">
<h1 class="display-4">404</h1>
<p class="lead">Page not found.</p>
<a href="<?= defined('APP_URL') ? APP_URL : '/' ?>/index.php?page=dashboard" class="btn btn-primary">Back to Dashboard</a>
</div></body></html>
