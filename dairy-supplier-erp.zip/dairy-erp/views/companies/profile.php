<?php
$pageTitle = 'Company Ledger';
$activeMenu = 'companies';
require APP_ROOT . '/views/layouts/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h5 class="mb-0"><?= e($company['company_name']) ?></h5>
    <small class="text-muted"><?= e($company['company_code']) ?> · <?= e($company['city']) ?>, <?= e($company['state']) ?></small>
  </div>
  <div>
    <span class="badge bg-<?= $outstanding > 0 ? 'danger' : 'success' ?> fs-6">Outstanding: <?= format_money($outstanding) ?></span>
    <button class="btn btn-outline-secondary ms-2" onclick="window.print()"><i class="fa-solid fa-print me-1"></i>Print</button>
  </div>
</div>

<div class="card p-3">
  <table class="table table-sm table-striped">
    <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Remarks</th></tr></thead>
    <tbody>
      <?php foreach ($ledger as $row): ?>
        <tr>
          <td><?= format_date($row['txn_date']) ?></td>
          <td><span class="badge bg-light text-dark"><?= e(str_replace('_', ' ', $row['txn_type'])) ?></span></td>
          <td><?= e($row['reference_no']) ?></td>
          <td class="text-danger"><?= $row['debit'] > 0 ? format_money($row['debit']) : '' ?></td>
          <td class="text-success"><?= $row['credit'] > 0 ? format_money($row['credit']) : '' ?></td>
          <td class="fw-semibold"><?= format_money($row['running_balance']) ?></td>
          <td><?= e($row['remarks']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($ledger)): ?>
        <tr><td colspan="7" class="text-center text-muted">No transactions yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
