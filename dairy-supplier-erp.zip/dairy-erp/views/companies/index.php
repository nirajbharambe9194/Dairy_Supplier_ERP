<?php
$pageTitle = 'Companies';
$activeMenu = 'companies';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Companies</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#companyModal" onclick="resetCompanyForm()">
    <i class="fa-solid fa-plus me-1"></i>Add Company
  </button>
</div>

<div class="card p-3">
  <table id="companiesTable" class="table table-hover align-middle w-100">
    <thead>
      <tr>
        <th>Code</th><th>Name</th><th>Contact</th><th>City</th><th>GST</th><th>Credit Limit</th><th>Status</th><th>Actions</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="companyModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form id="companyForm">
        <div class="modal-header">
          <h5 class="modal-title" id="companyModalTitle">Add Company</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
          <input type="hidden" name="id" id="c_id">
          <div class="col-md-6">
            <label class="form-label">Company Name *</label>
            <input class="form-control" name="company_name" id="c_company_name" required>
          </div>
          <div class="col-md-6">
            <label class="form-label">Contact Person</label>
            <input class="form-control" name="contact_person" id="c_contact_person">
          </div>
          <div class="col-md-6">
            <label class="form-label">Phone</label>
            <input class="form-control" name="phone" id="c_phone">
          </div>
          <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="c_email">
          </div>
          <div class="col-md-8">
            <label class="form-label">Address</label>
            <input class="form-control" name="address" id="c_address">
          </div>
          <div class="col-md-4">
            <label class="form-label">City</label>
            <input class="form-control" name="city" id="c_city">
          </div>
          <div class="col-md-4">
            <label class="form-label">State</label>
            <input class="form-control" name="state" id="c_state">
          </div>
          <div class="col-md-4">
            <label class="form-label">GST Number</label>
            <input class="form-control" name="gst_number" id="c_gst_number">
          </div>
          <div class="col-md-4">
            <label class="form-label">PAN Number</label>
            <input class="form-control" name="pan_number" id="c_pan_number">
          </div>
          <div class="col-md-4">
            <label class="form-label">Payment Terms</label>
            <input class="form-control" name="payment_terms" id="c_payment_terms" placeholder="e.g. Net 30">
          </div>
          <div class="col-md-4">
            <label class="form-label">Credit Limit</label>
            <input type="number" step="0.01" class="form-control" name="credit_limit" id="c_credit_limit" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">Opening Balance</label>
            <input type="number" step="0.01" class="form-control" name="opening_balance" id="c_opening_balance" value="0">
          </div>
          <div class="col-md-4">
            <label class="form-label">Status</label>
            <select class="form-select" name="status" id="c_status">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Bank Name</label>
            <input class="form-control" name="bank_name" id="c_bank_name">
          </div>
          <div class="col-md-4">
            <label class="form-label">Account No.</label>
            <input class="form-control" name="bank_account_no" id="c_bank_account_no">
          </div>
          <div class="col-md-4">
            <label class="form-label">IFSC</label>
            <input class="form-control" name="bank_ifsc" id="c_bank_ifsc">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Company</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let companiesTable;
const isAdmin = <?= json_encode(current_role() === 'admin') ?>;

function resetCompanyForm() {
  $('#companyForm')[0].reset();
  $('#c_id').val('');
  $('#companyModalTitle').text('Add Company');
}

function loadCompanies() {
  apiCall('companies', 'list', {}, 'GET').done(function (res) {
    if (companiesTable) { companiesTable.destroy(); }
    const rows = res.data || [];
    companiesTable = $('#companiesTable').DataTable({
      data: rows,
      columns: [
        { data: 'company_code' },
        { data: 'company_name' },
        { data: 'contact_person', defaultContent: '-' },
        { data: 'city', defaultContent: '-' },
        { data: 'gst_number', defaultContent: '-' },
        { data: 'credit_limit', render: d => money(d) },
        { data: 'status', render: s => `<span class="badge bg-${s === 'active' ? 'success' : 'secondary'}">${s}</span>` },
        {
          data: null, orderable: false, render: (row) => `
            <a href="${window.APP_URL}/index.php?page=company_profile&id=${row.id}" class="btn btn-sm btn-outline-primary" title="Ledger"><i class="fa-solid fa-book"></i></a>
            <button class="btn btn-sm btn-outline-secondary" onclick='editCompany(${JSON.stringify(row)})'><i class="fa-solid fa-pen"></i></button>
            ${isAdmin ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteCompany(${row.id})"><i class="fa-solid fa-trash"></i></button>` : ''}
          `
        },
      ]
    });
  });
}

function editCompany(row) {
  $('#companyModalTitle').text('Edit Company');
  $('#c_id').val(row.id);
  ['company_name','contact_person','phone','email','address','city','state','gst_number','pan_number','payment_terms','credit_limit','status','bank_name','bank_account_no','bank_ifsc']
    .forEach(f => $('#c_' + f).val(row[f]));
  new bootstrap.Modal(document.getElementById('companyModal')).show();
}

function deleteCompany(id) {
  if (!confirm('Delete this company? This cannot be undone.')) return;
  apiCall('companies', 'delete', { id }).done(function (res) {
    showToast(res.message, res.success ? 'success' : 'danger');
    if (res.success) loadCompanies();
  });
}

$('#companyForm').on('submit', function (e) {
  e.preventDefault();
  const id = $('#c_id').val();
  const data = $(this).serialize();
  apiCall('companies', id ? 'update' : 'store', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('companyModal')).hide();
        loadCompanies();
      }
    });
});

$(loadCompanies);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
