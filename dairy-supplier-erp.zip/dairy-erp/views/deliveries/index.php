<?php
$pageTitle = 'Deliveries';
$activeMenu = 'deliveries';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Deliveries / Supply</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#deliveryModal" onclick="resetDeliveryForm()">
    <i class="fa-solid fa-plus me-1"></i>New Delivery
  </button>
</div>

<div class="card p-3">
  <table id="deliveriesTable" class="table table-hover align-middle w-100">
    <thead><tr><th>Delivery #</th><th>Date</th><th>Distributor</th><th>Route</th><th>Total</th><th>Actions</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<div class="modal fade" id="deliveryModal" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <form id="deliveryForm">
        <div class="modal-header">
          <h5 class="modal-title">New Delivery</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label">Distributor *</label>
              <select class="form-select" id="del_distributor_id" required>
                <option value="">Select</option>
                <?php foreach ($distributors as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['distributor_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label">Delivery Date *</label>
              <input type="date" class="form-control" id="del_delivery_date" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-3 d-flex align-items-end">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="del_generate_invoice" checked>
                <label class="form-check-label" for="del_generate_invoice">Auto-generate invoice</label>
              </div>
            </div>
          </div>

          <table class="table table-sm" id="deliveryItemsTable">
            <thead><tr><th style="width:25%">Product</th><th>Ordered</th><th>Delivered</th><th>Damage</th><th>Rate</th><th>Amount</th><th></th></tr></thead>
            <tbody></tbody>
          </table>
          <button type="button" class="btn btn-sm btn-outline-success" id="addDeliveryLine"><i class="fa-solid fa-plus me-1"></i>Add Line</button>

          <div class="row g-3 mt-3">
            <div class="col-12"><label class="form-label">Remarks</label><input class="form-control" id="del_remarks"></div>
          </div>
          <div class="text-end mt-3 fs-5">Total: <span class="fw-bold" id="del_grand_total">₹0.00</span></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Delivery</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="viewDeliveryModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Delivery Details</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="viewDeliveryBody"></div>
    </div>
  </div>
</div>

<script>
const PRODUCTS_D = <?= json_encode($products) ?>;
let deliveriesTable;

function delProductOptions() {
  return '<option value="">Select</option>' + PRODUCTS_D.map(p => `<option value="${p.id}" data-price="${p.selling_price}" data-unit="${p.unit}">${p.product_name}</option>`).join('');
}

function addDeliveryLine() {
  $('#deliveryItemsTable tbody').append(`<tr>
    <td><select class="form-select form-select-sm dprod-select">${delProductOptions()}</select></td>
    <td><input type="number" step="0.001" class="form-control form-control-sm ordered" value="0"></td>
    <td><input type="number" step="0.001" class="form-control form-control-sm delivered" value="0"></td>
    <td><input type="number" step="0.001" class="form-control form-control-sm damage" value="0"></td>
    <td><input type="number" step="0.01" class="form-control form-control-sm drate" value="0"></td>
    <td class="dline-total align-middle">0.00</td>
    <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="$(this).closest('tr').remove(); recalcDelivery();"><i class="fa-solid fa-xmark"></i></button></td>
  </tr>`);
}

$(document).on('change', '.dprod-select', function () {
  const opt = $(this).find(':selected');
  $(this).closest('tr').find('.drate').val(opt.data('price') || 0);
  recalcDelivery();
});
$(document).on('input', '.ordered, .delivered, .damage, .drate', recalcDelivery);

function recalcDelivery() {
  let grand = 0;
  $('#deliveryItemsTable tbody tr').each(function () {
    const delivered = parseFloat($(this).find('.delivered').val()) || 0;
    const rate = parseFloat($(this).find('.drate').val()) || 0;
    const total = delivered * rate;
    $(this).find('.dline-total').text(total.toFixed(2));
    grand += total;
  });
  $('#del_grand_total').text(money(grand));
}
$('#addDeliveryLine').on('click', addDeliveryLine);

function resetDeliveryForm() {
  $('#deliveryForm')[0].reset();
  $('#deliveryItemsTable tbody').empty();
  $('#del_delivery_date').val(new Date().toISOString().slice(0,10));
  addDeliveryLine();
  recalcDelivery();
}

$('#deliveryForm').on('submit', function (e) {
  e.preventDefault();
  const items = [];
  let valid = true;
  $('#deliveryItemsTable tbody tr').each(function () {
    const productId = $(this).find('.dprod-select').val();
    if (!productId) { valid = false; return; }
    items.push({
      product_id: productId,
      ordered_qty: $(this).find('.ordered').val() || 0,
      delivered_qty: $(this).find('.delivered').val() || 0,
      damage_qty: $(this).find('.damage').val() || 0,
      rate: $(this).find('.drate').val() || 0,
    });
  });
  if (!valid || items.length === 0) { showToast('Please complete every product line before saving.', 'danger'); return; }

  apiCall('deliveries', 'store', {
    distributor_id: $('#del_distributor_id').val(),
    delivery_date: $('#del_delivery_date').val(),
    remarks: $('#del_remarks').val(),
    generate_invoice: $('#del_generate_invoice').is(':checked') ? 1 : 0,
    items: JSON.stringify(items),
  }).done(function (res) {
    showToast(res.message, res.success ? 'success' : 'danger');
    if (res.success) { bootstrap.Modal.getInstance(document.getElementById('deliveryModal')).hide(); loadDeliveries(); }
  });
});

function loadDeliveries() {
  apiCall('deliveries', 'list', {}, 'GET').done(function (res) {
    if (deliveriesTable) deliveriesTable.destroy();
    deliveriesTable = $('#deliveriesTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'delivery_no' }, { data: 'delivery_date' }, { data: 'distributor_name' }, { data: 'route', defaultContent: '-' },
        { data: 'total_amount', render: d => money(d) },
        { data: null, orderable: false, render: r => `<button class="btn btn-sm btn-outline-primary" onclick="viewDelivery(${r.id})"><i class="fa-solid fa-eye"></i></button>` },
      ]
    });
  });
}

function viewDelivery(id) {
  apiCall('deliveries', 'view', { id }, 'GET').done(function (res) {
    const d = res.data;
    let rows = d.items.map(i => `<tr><td>${i.product_name}</td><td>${i.ordered_qty}</td><td>${i.delivered_qty}</td><td>${i.short_qty}</td><td>${i.damage_qty}</td><td>${money(i.amount)}</td></tr>`).join('');
    $('#viewDeliveryBody').html(`
      <p><b>${d.delivery_no}</b> · ${d.delivery_date}</p>
      <table class="table table-sm"><thead><tr><th>Product</th><th>Ordered</th><th>Delivered</th><th>Short</th><th>Damage</th><th>Amount</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="text-end fs-5">Total: <b>${money(d.total_amount)}</b></p>
    `);
    new bootstrap.Modal(document.getElementById('viewDeliveryModal')).show();
  });
}

$(function () { resetDeliveryForm(); loadDeliveries(); });
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
