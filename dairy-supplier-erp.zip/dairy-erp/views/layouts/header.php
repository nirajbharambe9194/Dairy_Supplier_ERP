<?php
/**
 * Shared layout header. Expects (all optional):
 *   $pageTitle   - string shown in <title> and breadcrumb
 *   $activeMenu  - string key matching the sidebar item to highlight
 */
if (!defined('APP_ROOT')) {
    exit('Direct access not permitted.');
}
$pageTitle = $pageTitle ?? 'Dashboard';
$activeMenu = $activeMenu ?? 'dashboard';
$companyName = get_setting('company_name', APP_NAME);
$logoPath = get_setting('logo_path', '');
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> · <?= e($companyName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div id="toastHost" class="toast-container position-fixed top-0 end-0 p-3" style="z-index:1080"></div>

<nav class="navbar navbar-expand top-navbar px-3">
  <button class="btn btn-link text-white d-lg-none" id="mobileSidebarToggle"><i class="fa-solid fa-bars"></i></button>
  <button class="btn btn-link text-white d-none d-lg-inline" id="sidebarToggle"><i class="fa-solid fa-bars"></i></button>
  <span class="navbar-brand ms-2 fw-semibold"><i class="fa-solid fa-cow me-2"></i><?= e($companyName) ?></span>
  <div class="ms-auto d-flex align-items-center gap-3">
    <button class="btn btn-link text-white" id="themeToggle" title="Toggle dark mode"><i class="fa-solid fa-moon"></i></button>
    <div class="dropdown">
      <button class="btn btn-link text-white dropdown-toggle" data-bs-toggle="dropdown">
        <i class="fa-solid fa-user-circle me-1"></i><?= e($_SESSION['full_name'] ?? '') ?>
        <span class="badge bg-light text-dark ms-1"><?= e(ucfirst($_SESSION['role_name'] ?? '')) ?></span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="<?= APP_URL ?>/index.php?page=logout"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="app-wrapper">
  <aside class="sidebar" id="sidebar">
    <ul class="nav flex-column">
      <?php
      $menu = [
        'dashboard' => ['Dashboard', 'fa-gauge-high'],
        'companies' => ['Companies', 'fa-industry'],
        'products' => ['Products', 'fa-jar'],
        'purchases' => ['Purchases', 'fa-cart-shopping'],
        'purchase_returns' => ['Purchase Returns', 'fa-rotate-left'],
        'distributors' => ['Distributors', 'fa-truck-field'],
        'daily_demand' => ['Daily Demand', 'fa-calendar-check'],
        'deliveries' => ['Deliveries', 'fa-truck-fast'],
        'billing' => ['Billing / Invoices', 'fa-file-invoice-dollar'],
        'payments' => ['Payments', 'fa-money-bill-transfer'],
        'ledgers' => ['Ledgers', 'fa-book'],
        'reports' => ['Reports', 'fa-chart-line'],
      ];
      foreach ($menu as $key => [$label, $icon]):
        $active = $activeMenu === $key ? 'active' : '';
      ?>
        <li class="nav-item">
          <a class="nav-link <?= $active ?>" href="<?= APP_URL ?>/index.php?page=<?= $key ?>">
            <i class="fa-solid <?= $icon ?> me-2"></i><span class="menu-label"><?= $label ?></span>
          </a>
        </li>
      <?php endforeach; ?>
      <?php if (current_role() === 'admin'): ?>
        <li class="nav-item">
          <a class="nav-link <?= $activeMenu === 'settings' ? 'active' : '' ?>" href="<?= APP_URL ?>/index.php?page=settings">
            <i class="fa-solid fa-gear me-2"></i><span class="menu-label">Settings</span>
          </a>
        </li>
      <?php endif; ?>
    </ul>
  </aside>

  <main class="main-content">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php?page=dashboard">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?= e($pageTitle) ?></li>
      </ol>
    </nav>
