  </main>
</div>

<script>window.APP_URL = <?= json_encode(APP_URL) ?>; window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>; window.CURRENCY = <?= json_encode(get_setting('currency_symbol', 'Rs.')) ?>;</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script src="<?= APP_URL ?>/assets/js/app.js"></script>
<?php if (!empty($pageScript)): ?>
<script src="<?= APP_URL ?>/assets/js/<?= e($pageScript) ?>"></script>
<?php endif; ?>
</body>
</html>
