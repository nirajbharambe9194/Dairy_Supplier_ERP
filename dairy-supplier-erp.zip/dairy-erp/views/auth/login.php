<?php
$companyName = get_setting('company_name', APP_NAME);
$error = $_SESSION['login_error'] ?? null;
unset($_SESSION['login_error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login · <?= e($companyName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
  body { background: linear-gradient(135deg,#204d37,#2f6f4f); min-height:100vh; display:flex; align-items:center; }
  .login-card { max-width: 400px; margin: auto; border-radius: 1rem; box-shadow: 0 10px 40px rgba(0,0,0,.25); }
</style>
</head>
<body>
  <div class="container">
    <div class="card login-card p-4">
      <div class="text-center mb-3">
        <i class="fa-solid fa-cow fa-2x text-success"></i>
        <h4 class="mt-2 mb-0"><?= e($companyName) ?></h4>
        <small class="text-muted">Dairy Supplier ERP</small>
      </div>
      <?php if ($error): ?>
        <div class="alert alert-danger py-2"><?= e($error) ?></div>
      <?php endif; ?>
      <form method="post" action="<?= APP_URL ?>/index.php?page=do_login">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Username or Email</label>
          <input type="text" name="username" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success w-100">
          <i class="fa-solid fa-right-to-bracket me-1"></i> Sign In
        </button>
      </form>
      <p class="text-center text-muted small mt-3 mb-0">
        Default admin: <code>admin</code> / <code>Admin@123</code> (change after first login)
      </p>
    </div>
  </div>
</body>
</html>
