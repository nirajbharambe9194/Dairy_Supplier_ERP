<?php
$pageTitle = 'Distributors';
$activeMenu = 'distributors';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Distributors</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#distModal" onclick="resetDistForm()">
    <i class="fa-solid fa-plus me-1"></i>Add Distributor
  </button>
</div>

<div class="card p-3">
  <table id="distributorsTable" class="table table-hover align-middle w-100">
    <thead><tr><th>Code</th><th>Name</th><th>Shop</th><th>Route</th><th>Phone</th><th>Outstanding</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<div class="modal fade" id="distModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form id="distForm">
        <div class="modal-header">
          <h5 class="modal-title" id="distModalTitle">Add Distributor</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body row g-3">
          <input type="hidden" name="id" id="d_id">
          <div class="col-md-6"><label class="form-label">Distributor Name *</label><input class="form-control" name="distributor_name" id="d_distributor_name" required></div>
          <div class="col-md-6"><label class="form-label">Shop Name</label><input class="form-control" name="shop_name" id="d_shop_name"></div>
          <div class="col-md-8"><label class="form-label">Address</label><input class="form-control" name="address" id="d_address"></div>
          <div class="col-md-4"><label class="form-label">Route</label><input class="form-control" name="route" id="d_route" list="routeList"></div>
          <datalist id="routeList"><?php foreach ($routes as $r): ?><option value="<?= e($r) ?>"><?php endforeach; ?></datalist>
          <div class="col-md-4"><label class="form-label">City</label><input class="form-control" name="city" id="d_city"></div>
          <div class="col-md-4"><label class="form-label">State</label><input class="form-control" name="state" id="d_state"></div>
          <div class="col-md-4"><label class="form-label">Phone</label><input class="form-control" name="phone" id="d_phone"></div>
          <div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" id="d_email"></div>
          <div class="col-md-6"><label class="form-label">GST Number</label><input class="form-control" name="gst_number" id="d_gst_number"></div>
          <div class="col-md-4">
            <label class="form-label">Payment Type</label>
            <select class="form-select" name="payment_type" id="d_payment_type">
              <option value="credit">Credit</option><option value="cash">Cash</option>
            </select>
          </div>
          <div class="col-md-4"><label class="form-label">Credit Limit</label><input type="number" step="0.01" class="form-control" name="credit_limit" id="d_credit_limit" value="0"></div>
          <div class="col-md-4"><label class="form-label">Opening Balance</label><input type="number" step="0.01" class="form-control" name="opening_balance" id="d_opening_balance" value="0"></div>
          <div class="col-md-4">
            <label class="form-label">Status</label>
            <select class="form-select" name="status" id="d_status"><option value="active">Active</option><option value="inactive">Inactive</option></select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Distributor</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
let distTable;
const isAdminD = <?= json_encode(current_role() === 'admin') ?>;

function resetDistForm() { $('#distForm')[0].reset(); $('#d_id').val(''); $('#distModalTitle').text('Add Distributor'); }

function loadDistributors() {
  apiCall('distributors', 'list', {}, 'GET').done(function (res) {
    if (distTable) distTable.destroy();
    distTable = $('#distributorsTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'distributor_code' }, { data: 'distributor_name' }, { data: 'shop_name', defaultContent: '-' },
        { data: 'route', defaultContent: '-' }, { data: 'phone', defaultContent: '-' },
        { data: 'outstanding_balance', render: d => `<span class="${d > 0 ? 'text-danger' : 'text-success'}">${money(d)}</span>` },
        { data: 'status', render: s => `<span class="badge bg-${s === 'active' ? 'success' : 'secondary'}">${s}</span>` },
        {
          data: null, orderable: false, render: (row) => `
            <a href="${window.APP_URL}/index.php?page=distributor_profile&id=${row.id}" class="btn btn-sm btn-outline-primary" title="Ledger"><i class="fa-solid fa-book"></i></a>
            <button class="btn btn-sm btn-outline-secondary" onclick='editDist(${JSON.stringify(row)})'><i class="fa-solid fa-pen"></i></button>
            ${isAdminD ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteDist(${row.id})"><i class="fa-solid fa-trash"></i></button>` : ''}
          `
        },
      ]
    });
  });
}

function editDist(row) {
  $('#distModalTitle').text('Edit Distributor');
  $('#d_id').val(row.id);
  ['distributor_name','shop_name','address','route','city','state','phone','email','gst_number','payment_type','credit_limit','status']
    .forEach(f => $('#d_' + f).val(row[f]));
  new bootstrap.Modal(document.getElementById('distModal')).show();
}

function deleteDist(id) {
  if (!confirm('Delete this distributor?')) return;
  apiCall('distributors', 'delete', { id }).done(function (res) {
    showToast(res.message, res.success ? 'success' : 'danger');
    if (res.success) loadDistributors();
  });
}

$('#distForm').on('submit', function (e) {
  e.preventDefault();
  const id = $('#d_id').val();
  apiCall('distributors', id ? 'update' : 'store', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(function (res) {
      showToast(res.message, res.success ? 'success' : 'danger');
      if (res.success) { bootstrap.Modal.getInstance(document.getElementById('distModal')).hide(); loadDistributors(); }
    });
});

$(loadDistributors);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
