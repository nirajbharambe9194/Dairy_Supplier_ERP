<?php
$pageTitle = 'Settings';
$activeMenu = 'settings';
require APP_ROOT . '/views/layouts/header.php';
?>

<ul class="nav nav-tabs mb-3">
  <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#generalTab">General</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#usersTab">Users</button></li>
  <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#backupTab">Backup</button></li>
</ul>

<div class="tab-content">
  <div class="tab-pane fade show active" id="generalTab">
    <div class="card p-3">
      <form id="settingsForm" class="row g-3">
        <div class="col-md-6"><label class="form-label">Company Name</label><input class="form-control" name="company_name" value="<?= e($settings['company_name'] ?? '') ?>"></div>
        <div class="col-md-6"><label class="form-label">Company GST</label><input class="form-control" name="company_gst" value="<?= e($settings['company_gst'] ?? '') ?>"></div>
        <div class="col-md-8"><label class="form-label">Address</label><input class="form-control" name="company_address" value="<?= e($settings['company_address'] ?? '') ?>"></div>
        <div class="col-md-4"><label class="form-label">Phone</label><input class="form-control" name="company_phone" value="<?= e($settings['company_phone'] ?? '') ?>"></div>
        <div class="col-md-4"><label class="form-label">Email</label><input class="form-control" name="company_email" value="<?= e($settings['company_email'] ?? '') ?>"></div>
        <div class="col-md-4"><label class="form-label">Currency Symbol</label><input class="form-control" name="currency_symbol" value="<?= e($settings['currency_symbol'] ?? 'Rs.') ?>"></div>
        <div class="col-md-4"><label class="form-label">Financial Year Start (MM-DD)</label><input class="form-control" name="financial_year_start" value="<?= e($settings['financial_year_start'] ?? '04-01') ?>"></div>
        <div class="col-md-3"><label class="form-label">Invoice Prefix</label><input class="form-control" name="invoice_prefix" value="<?= e($settings['invoice_prefix'] ?? 'INV-') ?>"></div>
        <div class="col-md-3"><label class="form-label">Purchase Prefix</label><input class="form-control" name="purchase_prefix" value="<?= e($settings['purchase_prefix'] ?? 'PUR-') ?>"></div>
        <div class="col-md-3"><label class="form-label">Delivery Prefix</label><input class="form-control" name="delivery_prefix" value="<?= e($settings['delivery_prefix'] ?? 'DEL-') ?>"></div>
        <div class="col-md-3"><label class="form-label">Return Prefix</label><input class="form-control" name="return_prefix" value="<?= e($settings['return_prefix'] ?? 'RET-') ?>"></div>
        <div class="col-12"><button type="submit" class="btn btn-success">Save Settings</button></div>
      </form>

      <hr>
      <form id="logoForm">
        <label class="form-label">Company Logo</label>
        <?php if (!empty($settings['logo_path'])): ?>
          <div class="mb-2"><img src="<?= APP_URL . '/' . e($settings['logo_path']) ?>" style="max-height:60px"></div>
        <?php endif; ?>
        <div class="input-group" style="max-width: 420px">
          <input type="file" class="form-control" name="logo" accept="image/*">
          <button class="btn btn-outline-primary" type="submit">Upload</button>
        </div>
      </form>
    </div>
  </div>

  <div class="tab-pane fade" id="usersTab">
    <div class="card p-3">
      <table class="table table-sm">
        <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th></tr></thead>
        <tbody>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><?= e($u['full_name']) ?></td>
              <td><?= e($u['username']) ?></td>
              <td><?= e($u['email']) ?></td>
              <td><span class="badge bg-secondary"><?= e($u['role_id'] == 1 ? 'Admin' : 'Staff') ?></span></td>
              <td><span class="badge bg-<?= $u['status'] === 'active' ? 'success' : 'secondary' ?>"><?= e($u['status']) ?></span></td>
              <td><?= $u['last_login'] ? format_date($u['last_login'], 'd-M-Y H:i') : '-' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <p class="text-muted small mb-0">User creation/role editing can be added here following the same AJAX CRUD pattern used for Companies/Products.</p>
    </div>
  </div>

  <div class="tab-pane fade" id="backupTab">
    <div class="card p-3">
      <p>Create a full database backup (SQL dump) for safekeeping.</p>
      <button class="btn btn-warning" id="backupBtn"><i class="fa-solid fa-database me-1"></i>Backup Now</button>
      <p class="text-muted small mt-2 mb-0">Requires the <code>mysqldump</code> binary to be available on the server PATH. Backups are saved to <code>/reports</code>.</p>
    </div>
  </div>
</div>

<script>
$('#settingsForm').on('submit', function (e) {
  e.preventDefault();
  apiCall('settings', 'update_general', $(this).serializeArray().reduce((a, x) => (a[x.name] = x.value, a), {}))
    .done(res => showToast(res.message, res.success ? 'success' : 'danger'));
});

$('#logoForm').on('submit', function (e) {
  e.preventDefault();
  const fd = new FormData(this);
  fd.append('csrf_token', window.CSRF_TOKEN);
  $.ajax({
    url: `${window.APP_URL}/ajax/router.php?module=settings&action=upload_logo`,
    method: 'POST', data: fd, contentType: false, processData: false, dataType: 'json',
  }).done(res => { showToast(res.message, res.success ? 'success' : 'danger'); if (res.success) location.reload(); });
});

$('#backupBtn').on('click', function () {
  apiCall('settings', 'backup', {}).done(res => showToast(res.message, res.success ? 'success' : 'danger'));
});
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
