<?php
$pageTitle = 'Reports';
$activeMenu = 'reports';
require APP_ROOT . '/views/layouts/header.php';
?>

<ul class="nav nav-pills mb-3 flex-wrap gap-2" id="reportTabs">
  <li class="nav-item"><button class="nav-link active" data-report="purchase">Purchase</button></li>
  <li class="nav-item"><button class="nav-link" data-report="sales">Sales</button></li>
  <li class="nav-item"><button class="nav-link" data-report="profit">Profit</button></li>
  <li class="nav-item"><button class="nav-link" data-report="inventory">Inventory</button></li>
  <li class="nav-item"><button class="nav-link" data-report="financial">Financial</button></li>
</ul>

<div class="card p-3 mb-3">
  <div class="row g-2 align-items-end" id="reportFilters">
    <div class="col-md-3"><label class="form-label small">From</label><input type="date" id="r_from" class="form-control form-control-sm" value="<?= date('Y-m-01') ?>"></div>
    <div class="col-md-3"><label class="form-label small">To</label><input type="date" id="r_to" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>"></div>
    <div class="col-md-3" id="r_subtype_wrap" style="display:none">
      <label class="form-label small">Sub-report</label>
      <select id="r_subtype" class="form-select form-select-sm"></select>
    </div>
    <div class="col-md-3">
      <button class="btn btn-outline-primary btn-sm" onclick="runReport()"><i class="fa-solid fa-play me-1"></i>Run</button>
      <button class="btn btn-outline-success btn-sm" onclick="exportCsv()"><i class="fa-solid fa-file-csv me-1"></i>CSV</button>
    </div>
  </div>
</div>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table table-sm table-striped" id="reportTable">
      <thead><tr id="reportHead"></tr></thead>
      <tbody id="reportBody"></tbody>
    </table>
  </div>
</div>

<script>
let currentReport = 'purchase';
let lastData = [];

const subtypes = {
  inventory: [['valuation', 'Stock Valuation'], ['movement', 'Stock Movement'], ['low_stock', 'Low Stock'], ['expiring', 'Expiring Products']],
  financial: [['company_outstanding', 'Company Outstanding'], ['distributor_outstanding', 'Distributor Outstanding'], ['collection', 'Collection Report']],
  profit: [['product', 'Product-wise Profit'], ['distributor', 'Distributor-wise Profit']],
};

$('#reportTabs button').on('click', function () {
  $('#reportTabs button').removeClass('active');
  $(this).addClass('active');
  currentReport = $(this).data('report');
  if (subtypes[currentReport]) {
    $('#r_subtype_wrap').show();
    $('#r_subtype').html(subtypes[currentReport].map(([v, l]) => `<option value="${v}">${l}</option>`).join(''));
  } else {
    $('#r_subtype_wrap').hide();
  }
  runReport();
});

function runReport() {
  const from = $('#r_from').val(), to = $('#r_to').val(), sub = $('#r_subtype').val();
  let module = 'reports', action = currentReport, params = { from, to };

  if (currentReport === 'inventory') { params.type = sub || 'valuation'; }
  if (currentReport === 'financial') { params.type = sub || 'company_outstanding'; }
  if (currentReport === 'profit') { params.by = sub || 'product'; }

  apiCall(module, action, params, 'GET').done(function (res) {
    lastData = res.data || [];
    renderReportTable(lastData);
  });
}

function renderReportTable(rows) {
  const head = $('#reportHead').empty();
  const body = $('#reportBody').empty();
  if (!rows.length) { body.append('<tr><td class="text-muted text-center">No data for the selected range.</td></tr>'); return; }
  const cols = Object.keys(rows[0]).filter(c => !['items'].includes(c));
  cols.forEach(c => head.append(`<th>${c.replace(/_/g,' ')}</th>`));
  rows.forEach(r => {
    const tr = $('<tr>');
    cols.forEach(c => tr.append(`<td>${r[c] ?? ''}</td>`));
    body.append(tr);
  });
}

function exportCsv() {
  if (!lastData.length) { showToast('Run a report first.', 'warning'); return; }
  const cols = Object.keys(lastData[0]).filter(c => !['items'].includes(c));
  let csv = cols.join(',') + '\n';
  lastData.forEach(r => { csv += cols.map(c => `"${(r[c] ?? '').toString().replace(/"/g,'""')}"`).join(',') + '\n'; });
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${currentReport}_report.csv`;
  a.click();
}

$(runReport);
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
