<?php
$pageTitle = 'Purchases';
$activeMenu = 'purchases';
require APP_ROOT . '/views/layouts/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h5 class="mb-0">Purchases (Company → Supplier)</h5>
  <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#purchaseModal" onclick="resetPurchaseForm()">
    <i class="fa-solid fa-plus me-1"></i>New Purchase
  </button>
</div>

<div class="card p-3 mb-3">
  <div class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label small">From</label><input type="date" id="f_from" class="form-control form-control-sm"></div>
    <div class="col-md-3"><label class="form-label small">To</label><input type="date" id="f_to" class="form-control form-control-sm"></div>
    <div class="col-md-3">
      <label class="form-label small">Company</label>
      <select id="f_company" class="form-select form-select-sm">
        <option value="">All Companies</option>
        <?php foreach ($companies as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['company_name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <button class="btn btn-outline-primary btn-sm w-100" onclick="loadPurchases()"><i class="fa-solid fa-filter me-1"></i>Filter</button>
    </div>
  </div>
</div>

<div class="card p-3">
  <table id="purchasesTable" class="table table-hover align-middle w-100">
    <thead><tr><th>Purchase #</th><th>Date</th><th>Company</th><th>Invoice #</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<!-- New Purchase Modal -->
<div class="modal fade" id="purchaseModal" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <form id="purchaseForm">
        <div class="modal-header">
          <h5 class="modal-title">New Purchase Entry</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3 mb-3">
            <div class="col-md-4">
              <label class="form-label">Company *</label>
              <select class="form-select" id="pu_company_id" required>
                <option value="">Select company</option>
                <?php foreach ($companies as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['company_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label">Purchase Date *</label>
              <input type="date" class="form-control" id="pu_purchase_date" value="<?= date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Company Invoice #</label>
              <input class="form-control" id="pu_company_invoice_no">
            </div>
            <div class="col-md-2">
              <label class="form-label">Invoice Date</label>
              <input type="date" class="form-control" id="pu_invoice_date">
            </div>
          </div>

          <table class="table table-sm" id="purchaseItemsTable">
            <thead>
              <tr>
                <th style="width:20%">Product</th><th>Batch #</th><th>Expiry</th><th>Qty</th><th>Unit</th><th>Price</th><th>GST%</th><th>Discount</th><th>Line Total</th><th></th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
          <button type="button" class="btn btn-sm btn-outline-success" id="addPurchaseLine"><i class="fa-solid fa-plus me-1"></i>Add Line</button>

          <div class="row g-3 mt-3">
            <div class="col-md-3">
              <label class="form-label">Freight Charges</label>
              <input type="number" step="0.01" class="form-control" id="pu_freight_charges" value="0">
            </div>
            <div class="col-md-3">
              <label class="form-label">Discount Amount</label>
              <input type="number" step="0.01" class="form-control" id="pu_discount_amount" value="0">
            </div>
            <div class="col-md-6">
              <label class="form-label">Remarks</label>
              <input class="form-control" id="pu_remarks">
            </div>
          </div>
          <div class="text-end mt-3 fs-5">Grand Total: <span class="fw-bold" id="pu_grand_total">₹0.00</span></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Purchase</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- View Purchase Modal -->
<div class="modal fade" id="viewPurchaseModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Purchase Details</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body" id="viewPurchaseBody"></div>
    </div>
  </div>
</div>

<script>
const PRODUCTS = <?= json_encode($products) ?>;
let purchasesTable;

function productOptions(selected = '') {
  return '<option value="">Select</option>' + PRODUCTS.map(p =>
    `<option value="${p.id}" data-price="${p.purchase_price}" data-gst="${p.gst_percent}" data-unit="${p.unit}" ${p.id == selected ? 'selected' : ''}>${p.product_name}</option>`
  ).join('');
}

function addPurchaseLine() {
  const row = $(`<tr>
    <td><select class="form-select form-select-sm prod-select">${productOptions()}</select></td>
    <td><input class="form-control form-control-sm batch"></td>
    <td><input type="date" class="form-control form-control-sm expiry"></td>
    <td><input type="number" step="0.001" class="form-control form-control-sm qty" value="1"></td>
    <td><input class="form-control form-control-sm unit" readonly></td>
    <td><input type="number" step="0.01" class="form-control form-control-sm price" value="0"></td>
    <td><input type="number" step="0.01" class="form-control form-control-sm gst" value="0"></td>
    <td><input type="number" step="0.01" class="form-control form-control-sm disc" value="0"></td>
    <td class="line-total align-middle">0.00</td>
    <td><button type="button" class="btn btn-sm btn-outline-danger remove-line"><i class="fa-solid fa-xmark"></i></button></td>
  </tr>`);
  $('#purchaseItemsTable tbody').append(row);
}

$(document).on('change', '.prod-select', function () {
  const opt = $(this).find(':selected');
  const row = $(this).closest('tr');
  row.find('.price').val(opt.data('price') || 0);
  row.find('.gst').val(opt.data('gst') || 0);
  row.find('.unit').val(opt.data('unit') || '');
  recalcPurchase();
});
$(document).on('input', '.qty, .price, .gst, .disc', recalcPurchase);
$(document).on('click', '.remove-line', function () { $(this).closest('tr').remove(); recalcPurchase(); });

function recalcPurchase() {
  let grand = 0;
  $('#purchaseItemsTable tbody tr').each(function () {
    const qty = parseFloat($(this).find('.qty').val()) || 0;
    const price = parseFloat($(this).find('.price').val()) || 0;
    const gst = parseFloat($(this).find('.gst').val()) || 0;
    const disc = parseFloat($(this).find('.disc').val()) || 0;
    const subtotal = qty * price - disc;
    const total = subtotal + (subtotal * gst / 100);
    $(this).find('.line-total').text(total.toFixed(2));
    grand += total;
  });
  grand += parseFloat($('#pu_freight_charges').val()) || 0;
  $('#pu_grand_total').text(money(grand));
}
$(document).on('input', '#pu_freight_charges, #pu_discount_amount', recalcPurchase);
$('#addPurchaseLine').on('click', addPurchaseLine);

function resetPurchaseForm() {
  $('#purchaseForm')[0].reset();
  $('#purchaseItemsTable tbody').empty();
  $('#pu_purchase_date').val(new Date().toISOString().slice(0,10));
  addPurchaseLine();
  recalcPurchase();
}

$('#purchaseForm').on('submit', function (e) {
  e.preventDefault();
  const items = [];
  let valid = true;
  $('#purchaseItemsTable tbody tr').each(function () {
    const productId = $(this).find('.prod-select').val();
    const qty = parseFloat($(this).find('.qty').val()) || 0;
    if (!productId || qty <= 0) { valid = false; return; }
    items.push({
      product_id: productId,
      batch_number: $(this).find('.batch').val(),
      expiry_date: $(this).find('.expiry').val(),
      quantity: qty,
      unit: $(this).find('.unit').val(),
      purchase_price: parseFloat($(this).find('.price').val()) || 0,
      gst_percent: parseFloat($(this).find('.gst').val()) || 0,
      discount: parseFloat($(this).find('.disc').val()) || 0,
    });
  });
  if (!valid || items.length === 0) { showToast('Please complete every product line before saving.', 'danger'); return; }

  apiCall('purchases', 'store', {
    company_id: $('#pu_company_id').val(),
    purchase_date: $('#pu_purchase_date').val(),
    company_invoice_no: $('#pu_company_invoice_no').val(),
    invoice_date: $('#pu_invoice_date').val(),
    freight_charges: $('#pu_freight_charges').val(),
    discount_amount: $('#pu_discount_amount').val(),
    remarks: $('#pu_remarks').val(),
    items: JSON.stringify(items),
  }).done(function (res) {
    showToast(res.message, res.success ? 'success' : 'danger');
    if (res.success) { bootstrap.Modal.getInstance(document.getElementById('purchaseModal')).hide(); loadPurchases(); }
  });
});

function loadPurchases() {
  apiCall('purchases', 'list', { from: $('#f_from').val(), to: $('#f_to').val(), company_id: $('#f_company').val() }, 'GET').done(function (res) {
    if (purchasesTable) purchasesTable.destroy();
    purchasesTable = $('#purchasesTable').DataTable({
      data: res.data || [],
      columns: [
        { data: 'purchase_no' },
        { data: 'purchase_date', render: d => d },
        { data: 'company_name' },
        { data: 'company_invoice_no', defaultContent: '-' },
        { data: 'total_amount', render: d => money(d) },
        { data: 'payment_status', render: s => `<span class="badge bg-${s === 'paid' ? 'success' : (s === 'partial' ? 'warning' : 'danger')}">${s}</span>` },
        { data: null, orderable: false, render: r => `<button class="btn btn-sm btn-outline-primary" onclick="viewPurchase(${r.id})"><i class="fa-solid fa-eye"></i></button>` },
      ]
    });
  });
}

function viewPurchase(id) {
  apiCall('purchases', 'view', { id }, 'GET').done(function (res) {
    const p = res.data;
    let rows = p.items.map(i => `<tr><td>${i.product_name}</td><td>${i.batch_number || '-'}</td><td>${i.quantity}</td><td>${money(i.purchase_price)}</td><td>${i.gst_percent}%</td><td>${money(i.line_total)}</td></tr>`).join('');
    $('#viewPurchaseBody').html(`
      <p><b>${p.purchase_no}</b> · ${p.purchase_date} · ${p.company_invoice_no || ''}</p>
      <table class="table table-sm"><thead><tr><th>Product</th><th>Batch</th><th>Qty</th><th>Price</th><th>GST</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="text-end fs-5">Grand Total: <b>${money(p.total_amount)}</b></p>
      <p>${p.remarks || ''}</p>
    `);
    new bootstrap.Modal(document.getElementById('viewPurchaseModal')).show();
  });
}

$(function () { resetPurchaseForm(); loadPurchases(); });
</script>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
