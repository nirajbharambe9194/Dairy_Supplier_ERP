<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$page = $_GET['page'] ?? ($_POST['page'] ?? 'dashboard');

switch ($page) {
    case 'login':
        (new AuthController())->showLogin();
        break;
    case 'do_login':
        (new AuthController())->login();
        break;
    case 'logout':
        (new AuthController())->logout();
        break;

    case 'dashboard':
        (new DashboardController())->index();
        break;

    case 'companies':
        (new CompanyController())->index();
        break;
    case 'company_profile':
        (new CompanyController())->profile();
        break;

    case 'products':
        (new ProductController())->index();
        break;

    case 'purchases':
        (new PurchaseController())->index();
        break;
    case 'purchase_returns':
        (new PurchaseReturnController())->index();
        break;

    case 'distributors':
        (new DistributorController())->index();
        break;
    case 'distributor_profile':
        (new DistributorController())->profile();
        break;

    case 'daily_demand':
        (new DailyDemandController())->index();
        break;

    case 'deliveries':
        (new DeliveryController())->index();
        break;

    case 'billing':
        (new BillingController())->index();
        break;
    case 'invoice_print':
        (new BillingController())->view();
        break;
    case 'invoice_pdf':
        (new BillingController())->downloadPdf();
        break;

    case 'payments':
        (new PaymentController())->index();
        break;

    case 'ledgers':
        (new LedgerController())->index();
        break;

    case 'reports':
        (new ReportController())->index();
        break;

    case 'settings':
        (new SettingsController())->index();
        break;

    default:
        http_response_code(404);
        require __DIR__ . '/views/errors/404.php';
}
