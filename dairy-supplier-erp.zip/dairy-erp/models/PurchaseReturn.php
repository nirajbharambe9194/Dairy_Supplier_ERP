<?php

class PurchaseReturn extends Model
{
    protected string $table = 'purchase_returns';

    public function generateNumber(): string
    {
        $prefix = get_setting('return_prefix', 'RET-');
        return generate_document_number($this->db, 'purchase_returns', 'return_no', $prefix);
    }

    public function createReturn(array $data): int
    {
        $productModel = new Product();
        $companyModel = new Company();

        $this->db->beginTransaction();
        try {
            $returnNo = $this->generateNumber();
            $amount = (float)$data['quantity'] * (float)$data['rate'];

            $returnId = $this->insert([
                'return_no' => $returnNo,
                'return_date' => $data['return_date'],
                'company_id' => $data['company_id'],
                'product_id' => $data['product_id'],
                'batch_number' => $data['batch_number'] ?? null,
                'quantity' => $data['quantity'],
                'rate' => $data['rate'],
                'amount' => $amount,
                'reason' => $data['reason'] ?? null,
                'credit_note_no' => $data['credit_note_no'] ?? null,
                'created_by' => $data['created_by'] ?? null,
            ]);

            $productModel->decreaseStock(
                (int)$data['product_id'],
                (float)$data['quantity'],
                'purchase_return',
                $data['return_date'],
                'purchase_returns',
                $returnId,
                "Purchase Return $returnNo"
            );

            // Credit note reduces what we owe the company.
            $companyModel->postLedgerEntry(
                (int)$data['company_id'],
                $data['return_date'],
                'purchase_return',
                $returnNo,
                'purchase_returns',
                $returnId,
                0,
                $amount,
                "Purchase Return $returnNo"
            );

            $this->db->commit();
            return $returnId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT pr.*, c.company_name, p.product_name FROM purchase_returns pr
                JOIN companies c ON c.id = pr.company_id
                JOIN products p ON p.id = pr.product_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND pr.return_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND pr.return_date <= :to';
            $params['to'] = $filters['to'];
        }
        $sql .= ' ORDER BY pr.return_date DESC, pr.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
