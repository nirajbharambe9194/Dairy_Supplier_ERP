<?php

class Company extends Model
{
    protected string $table = 'companies';

    public function generateCode(): string
    {
        return generate_document_number($this->db, 'companies', 'company_code', 'CMP-');
    }

    public function search(string $term = '', string $status = ''): array
    {
        $sql = 'SELECT * FROM companies WHERE 1=1';
        $params = [];
        if ($term !== '') {
            $sql .= ' AND (company_name LIKE :term1 OR company_code LIKE :term2 OR gst_number LIKE :term3)';
            $params['term1'] = $params['term2'] = $params['term3'] = "%$term%";
        }
        if ($status !== '') {
            $sql .= ' AND status = :status';
            $params['status'] = $status;
        }
        $sql .= ' ORDER BY company_name';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Current running balance owed TO this company (what we owe them). */
    public function getOutstandingBalance(int $companyId): float
    {
        $stmt = $this->db->prepare(
            'SELECT running_balance FROM company_ledgers WHERE company_id = :id ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute(['id' => $companyId]);
        $balance = $stmt->fetchColumn();
        if ($balance !== false) {
            return (float)$balance;
        }
        $company = $this->find($companyId);
        return $company ? (float)$company['opening_balance'] : 0.0;
    }

    /**
     * Post a ledger entry for a company. Debit increases what we owe (a purchase),
     * credit decreases it (a payment we made). Must run inside the caller's transaction.
     */
    public function postLedgerEntry(int $companyId, string $date, string $type, ?string $refNo, ?string $refTable, ?int $refId, float $debit, float $credit, string $remarks = ''): void
    {
        $previousBalance = $this->getOutstandingBalance($companyId);
        $newBalance = $previousBalance + $debit - $credit;

        $stmt = $this->db->prepare(
            'INSERT INTO company_ledgers (company_id, txn_date, txn_type, reference_no, reference_table, reference_id, debit, credit, running_balance, remarks)
             VALUES (:cid,:date,:type,:refno,:reftable,:refid,:debit,:credit,:balance,:remarks)'
        );
        $stmt->execute([
            'cid' => $companyId, 'date' => $date, 'type' => $type, 'refno' => $refNo,
            'reftable' => $refTable, 'refid' => $refId, 'debit' => $debit, 'credit' => $credit,
            'balance' => $newBalance, 'remarks' => $remarks,
        ]);
    }

    public function getLedger(int $companyId): array
    {
        $stmt = $this->db->prepare('SELECT * FROM company_ledgers WHERE company_id = :id ORDER BY txn_date, id');
        $stmt->execute(['id' => $companyId]);
        return $stmt->fetchAll();
    }

    public function totalPendingPayments(): float
    {
        $stmt = $this->db->query(
            "SELECT COALESCE(SUM(running_balance),0) FROM company_ledgers cl
             INNER JOIN (SELECT company_id, MAX(id) AS max_id FROM company_ledgers GROUP BY company_id) latest
             ON cl.id = latest.max_id"
        );
        return (float)$stmt->fetchColumn();
    }
}
