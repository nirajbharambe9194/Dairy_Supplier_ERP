<?php

class Product extends Model
{
    protected string $table = 'products';

    public function generateCode(): string
    {
        return generate_document_number($this->db, 'products', 'product_code', 'PRD-');
    }

    public function search(string $term = '', int $categoryId = 0, string $status = ''): array
    {
        $sql = 'SELECT p.*, c.category_name FROM products p LEFT JOIN product_categories c ON c.id = p.category_id WHERE 1=1';
        $params = [];
        if ($term !== '') {
            $sql .= ' AND (p.product_name LIKE :term1 OR p.product_code LIKE :term2 OR p.barcode LIKE :term3)';
            $params['term1'] = $params['term2'] = $params['term3'] = "%$term%";
        }
        if ($categoryId > 0) {
            $sql .= ' AND p.category_id = :cat';
            $params['cat'] = $categoryId;
        }
        if ($status !== '') {
            $sql .= ' AND p.status = :status';
            $params['status'] = $status;
        }
        $sql .= ' ORDER BY p.product_name';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function lowStock(): array
    {
        return $this->db->query(
            'SELECT * FROM products WHERE current_stock <= minimum_stock AND status = "active" ORDER BY current_stock ASC'
        )->fetchAll();
    }

    public function expiringSoon(int $days = 7): array
    {
        $stmt = $this->db->prepare(
            'SELECT pb.*, p.product_name, p.unit FROM product_batches pb
             JOIN products p ON p.id = pb.product_id
             WHERE pb.quantity > 0 AND pb.expiry_date IS NOT NULL
             AND pb.expiry_date <= DATE_ADD(CURDATE(), INTERVAL :days DAY)
             ORDER BY pb.expiry_date ASC'
        );
        $stmt->execute(['days' => $days]);
        return $stmt->fetchAll();
    }

    public function inventoryValue(): float
    {
        $stmt = $this->db->query('SELECT COALESCE(SUM(current_stock * purchase_price),0) FROM products');
        return (float)$stmt->fetchColumn();
    }

    public function categories(): array
    {
        return $this->db->query('SELECT * FROM product_categories ORDER BY category_name')->fetchAll();
    }

    /** Increase stock (purchase / return-in) and log the movement. Runs inside caller's transaction. */
    public function increaseStock(int $productId, float $qty, string $type, string $date, ?string $refTable = null, ?int $refId = null, string $remarks = ''): void
    {
        $stmt = $this->db->prepare('UPDATE products SET current_stock = current_stock + :qty WHERE id = :id');
        $stmt->execute(['qty' => $qty, 'id' => $productId]);
        $this->logStockMovement($productId, $type, $date, $qty, 0, $refTable, $refId, $remarks);
    }

    /** Decrease stock (delivery / damage / return-out) and log the movement. */
    public function decreaseStock(int $productId, float $qty, string $type, string $date, ?string $refTable = null, ?int $refId = null, string $remarks = ''): void
    {
        $stmt = $this->db->prepare('UPDATE products SET current_stock = current_stock - :qty WHERE id = :id');
        $stmt->execute(['qty' => $qty, 'id' => $productId]);
        $this->logStockMovement($productId, $type, $date, 0, $qty, $refTable, $refId, $remarks);
    }

    private function logStockMovement(int $productId, string $type, string $date, float $in, float $out, ?string $refTable, ?int $refId, string $remarks): void
    {
        $current = (float)$this->db->query("SELECT current_stock FROM products WHERE id = $productId")->fetchColumn();
        $stmt = $this->db->prepare(
            'INSERT INTO stock_transactions (product_id, txn_date, txn_type, reference_table, reference_id, quantity_in, quantity_out, balance_stock, remarks)
             VALUES (:pid,:date,:type,:reftable,:refid,:in,:out,:balance,:remarks)'
        );
        $stmt->execute([
            'pid' => $productId, 'date' => $date, 'type' => $type, 'reftable' => $refTable,
            'refid' => $refId, 'in' => $in, 'out' => $out, 'balance' => $current, 'remarks' => $remarks,
        ]);
    }

    public function addBatch(int $productId, ?string $batchNumber, ?string $expiryDate, float $qty, float $price): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO product_batches (product_id, batch_number, expiry_date, quantity, purchase_price)
             VALUES (:pid,:batch,:exp,:qty,:price)'
        );
        $stmt->execute(['pid' => $productId, 'batch' => $batchNumber, 'exp' => $expiryDate, 'qty' => $qty, 'price' => $price]);
    }
}
