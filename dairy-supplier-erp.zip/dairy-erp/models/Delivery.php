<?php

class Delivery extends Model
{
    protected string $table = 'deliveries';

    public function generateNumber(): string
    {
        $prefix = get_setting('delivery_prefix', 'DEL-');
        return generate_document_number($this->db, 'deliveries', 'delivery_no', $prefix);
    }

    /**
     * $items: array of ['product_id','ordered_qty','delivered_qty','damage_qty','rate']
     * Automatically reduces inventory, posts a distributor ledger debit ("sales entry"),
     * and returns the new delivery id so the caller can generate an invoice from it.
     */
    public function createDelivery(array $header, array $items): int
    {
        $productModel = new Product();
        $distributorModel = new Distributor();

        $this->db->beginTransaction();
        try {
            $deliveryNo = $this->generateNumber();
            $totalAmount = 0.0;
            foreach ($items as $item) {
                $totalAmount += (float)$item['delivered_qty'] * (float)$item['rate'];
            }

            $deliveryId = $this->insert([
                'delivery_no' => $deliveryNo,
                'delivery_date' => $header['delivery_date'],
                'distributor_id' => $header['distributor_id'],
                'total_amount' => $totalAmount,
                'remarks' => $header['remarks'] ?? null,
                'created_by' => $header['created_by'] ?? null,
            ]);

            $itemStmt = $this->db->prepare(
                'INSERT INTO delivery_items (delivery_id, product_id, ordered_qty, delivered_qty, damage_qty, rate, amount, remarks)
                 VALUES (:did,:pid,:ordered,:delivered,:damage,:rate,:amount,:remarks)'
            );

            foreach ($items as $item) {
                $lineAmount = (float)$item['delivered_qty'] * (float)$item['rate'];
                $itemStmt->execute([
                    'did' => $deliveryId,
                    'pid' => $item['product_id'],
                    'ordered' => $item['ordered_qty'] ?? 0,
                    'delivered' => $item['delivered_qty'],
                    'damage' => $item['damage_qty'] ?? 0,
                    'rate' => $item['rate'],
                    'amount' => $lineAmount,
                    'remarks' => $item['remarks'] ?? null,
                ]);

                $totalOut = (float)$item['delivered_qty'] + (float)($item['damage_qty'] ?? 0);
                if ($totalOut > 0) {
                    $productModel->decreaseStock(
                        (int)$item['product_id'],
                        $totalOut,
                        (float)($item['damage_qty'] ?? 0) > 0 && (float)$item['delivered_qty'] == 0 ? 'damage' : 'delivery',
                        $header['delivery_date'],
                        'deliveries',
                        $deliveryId,
                        "Delivery $deliveryNo"
                    );
                }
            }

            // Auto sales entry: distributor now owes us for what was delivered.
            $distributorModel->postLedgerEntry(
                (int)$header['distributor_id'],
                $header['delivery_date'],
                'delivery',
                $deliveryNo,
                'deliveries',
                $deliveryId,
                $totalAmount,
                0,
                "Delivery $deliveryNo"
            );

            $this->db->commit();
            return $deliveryId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getWithItems(int $deliveryId): ?array
    {
        $delivery = $this->find($deliveryId);
        if (!$delivery) {
            return null;
        }
        $stmt = $this->db->prepare(
            'SELECT di.*, p.product_name, p.unit FROM delivery_items di JOIN products p ON p.id = di.product_id WHERE delivery_id = :id'
        );
        $stmt->execute(['id' => $deliveryId]);
        $delivery['items'] = $stmt->fetchAll();
        return $delivery;
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT de.*, d.distributor_name, d.route FROM deliveries de
                JOIN distributors d ON d.id = de.distributor_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND de.delivery_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND de.delivery_date <= :to';
            $params['to'] = $filters['to'];
        }
        if (!empty($filters['distributor_id'])) {
            $sql .= ' AND de.distributor_id = :did';
            $params['did'] = $filters['distributor_id'];
        }
        if (!empty($filters['route'])) {
            $sql .= ' AND d.route = :route';
            $params['route'] = $filters['route'];
        }
        $sql .= ' ORDER BY de.delivery_date DESC, de.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function todaysTotal(): float
    {
        $stmt = $this->db->query('SELECT COALESCE(SUM(total_amount),0) FROM deliveries WHERE delivery_date = CURDATE()');
        return (float)$stmt->fetchColumn();
    }

    public function todaysCount(): int
    {
        $stmt = $this->db->query('SELECT COUNT(*) FROM deliveries WHERE delivery_date = CURDATE()');
        return (int)$stmt->fetchColumn();
    }
}
