<?php

class Distributor extends Model
{
    protected string $table = 'distributors';

    public function generateCode(): string
    {
        return generate_document_number($this->db, 'distributors', 'distributor_code', 'DIST-');
    }

    public function search(string $term = '', string $route = '', string $status = ''): array
    {
        $sql = 'SELECT * FROM distributors WHERE 1=1';
        $params = [];
        if ($term !== '') {
            $sql .= ' AND (distributor_name LIKE :term1 OR shop_name LIKE :term2 OR distributor_code LIKE :term3)';
            $params['term1'] = $params['term2'] = $params['term3'] = "%$term%";
        }
        if ($route !== '') {
            $sql .= ' AND route = :route';
            $params['route'] = $route;
        }
        if ($status !== '') {
            $sql .= ' AND status = :status';
            $params['status'] = $status;
        }
        $sql .= ' ORDER BY distributor_name';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function routes(): array
    {
        return array_column($this->db->query(
            'SELECT DISTINCT route FROM distributors WHERE route IS NOT NULL AND route <> "" ORDER BY route'
        )->fetchAll(), 'route');
    }

    /** What this distributor currently owes us. */
    public function getOutstandingBalance(int $distributorId): float
    {
        $stmt = $this->db->prepare(
            'SELECT running_balance FROM distributor_ledgers WHERE distributor_id = :id ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute(['id' => $distributorId]);
        $balance = $stmt->fetchColumn();
        if ($balance !== false) {
            return (float)$balance;
        }
        $d = $this->find($distributorId);
        return $d ? (float)$d['opening_balance'] : 0.0;
    }

    /** Debit = we billed them (invoice), credit = payment received from them. */
    public function postLedgerEntry(int $distributorId, string $date, string $type, ?string $refNo, ?string $refTable, ?int $refId, float $debit, float $credit, string $remarks = ''): void
    {
        $previousBalance = $this->getOutstandingBalance($distributorId);
        $newBalance = $previousBalance + $debit - $credit;

        $stmt = $this->db->prepare(
            'INSERT INTO distributor_ledgers (distributor_id, txn_date, txn_type, reference_no, reference_table, reference_id, debit, credit, running_balance, remarks)
             VALUES (:did,:date,:type,:refno,:reftable,:refid,:debit,:credit,:balance,:remarks)'
        );
        $stmt->execute([
            'did' => $distributorId, 'date' => $date, 'type' => $type, 'refno' => $refNo,
            'reftable' => $refTable, 'refid' => $refId, 'debit' => $debit, 'credit' => $credit,
            'balance' => $newBalance, 'remarks' => $remarks,
        ]);
    }

    public function getLedger(int $distributorId): array
    {
        $stmt = $this->db->prepare('SELECT * FROM distributor_ledgers WHERE distributor_id = :id ORDER BY txn_date, id');
        $stmt->execute(['id' => $distributorId]);
        return $stmt->fetchAll();
    }

    public function totalPendingPayments(): float
    {
        $stmt = $this->db->query(
            "SELECT COALESCE(SUM(running_balance),0) FROM distributor_ledgers dl
             INNER JOIN (SELECT distributor_id, MAX(id) AS max_id FROM distributor_ledgers GROUP BY distributor_id) latest
             ON dl.id = latest.max_id"
        );
        return (float)$stmt->fetchColumn();
    }

    public function creditLimitExceeded(int $distributorId): bool
    {
        $d = $this->find($distributorId);
        if (!$d || (float)$d['credit_limit'] <= 0) {
            return false;
        }
        return $this->getOutstandingBalance($distributorId) > (float)$d['credit_limit'];
    }
}
