<?php

class DistributorPayment extends Model
{
    protected string $table = 'distributor_payments';

    public function recordPayment(array $data): int
    {
        $distributorModel = new Distributor();
        $this->db->beginTransaction();
        try {
            $newBalance = $distributorModel->getOutstandingBalance((int)$data['distributor_id']) - (float)$data['amount'];

            $paymentId = $this->insert([
                'distributor_id' => $data['distributor_id'],
                'payment_date' => $data['payment_date'],
                'invoice_no' => $data['invoice_no'] ?? null,
                'payment_method' => $data['payment_method'],
                'transaction_reference' => $data['transaction_reference'] ?? null,
                'amount' => $data['amount'],
                'remaining_balance' => $newBalance,
                'remarks' => $data['remarks'] ?? null,
                'created_by' => $data['created_by'] ?? null,
            ]);

            $distributorModel->postLedgerEntry(
                (int)$data['distributor_id'],
                $data['payment_date'],
                'payment',
                $data['transaction_reference'] ?? ('PMT-' . $paymentId),
                'distributor_payments',
                $paymentId,
                0,
                (float)$data['amount'],
                'Payment received from distributor'
            );

            // If an invoice number was specified, mark it paid/partial and update its balance.
            if (!empty($data['invoice_no'])) {
                $invStmt = $this->db->prepare('SELECT * FROM invoices WHERE invoice_no = :no');
                $invStmt->execute(['no' => $data['invoice_no']]);
                $invoice = $invStmt->fetch();
                if ($invoice) {
                    $newReceived = (float)$invoice['payment_received'] + (float)$data['amount'];
                    $newOutstanding = max((float)$invoice['total_amount'] - $newReceived, 0);
                    $status = $newOutstanding <= 0 ? 'paid' : ($newReceived > 0 ? 'partial' : 'unpaid');
                    $this->db->prepare(
                        'UPDATE invoices SET payment_received = :recv, outstanding_balance = :out, status = :status WHERE id = :id'
                    )->execute(['recv' => $newReceived, 'out' => $newOutstanding, 'status' => $status, 'id' => $invoice['id']]);
                }
            }

            $this->db->commit();
            return $paymentId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT dp.*, d.distributor_name FROM distributor_payments dp JOIN distributors d ON d.id = dp.distributor_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND dp.payment_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND dp.payment_date <= :to';
            $params['to'] = $filters['to'];
        }
        if (!empty($filters['distributor_id'])) {
            $sql .= ' AND dp.distributor_id = :did';
            $params['did'] = $filters['distributor_id'];
        }
        $sql .= ' ORDER BY dp.payment_date DESC, dp.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
