<?php

class Purchase extends Model
{
    protected string $table = 'purchases';

    public function generateNumber(): string
    {
        $prefix = get_setting('purchase_prefix', 'PUR-');
        return generate_document_number($this->db, 'purchases', 'purchase_no', $prefix);
    }

    /**
     * Create a purchase header + line items. Automatically:
     *  - increases product stock and creates a batch record
     *  - posts a debit entry to the company ledger (we now owe them more)
     * $items: array of ['product_id','batch_number','expiry_date','quantity','unit','purchase_price','gst_percent','discount']
     */
    public function createPurchase(array $header, array $items): int
    {
        $productModel = new Product();
        $companyModel = new Company();

        $this->db->beginTransaction();
        try {
            $purchaseNo = $this->generateNumber();
            $totalAmount = 0.0;
            $gstTotal = 0.0;

            foreach ($items as $item) {
                $lineSubtotal = $item['quantity'] * $item['purchase_price'] - (float)($item['discount'] ?? 0);
                $lineGst = $lineSubtotal * ((float)$item['gst_percent'] / 100);
                $totalAmount += $lineSubtotal + $lineGst;
                $gstTotal += $lineGst;
            }
            $totalAmount += (float)($header['freight_charges'] ?? 0);

            $purchaseId = $this->insert([
                'purchase_no' => $purchaseNo,
                'purchase_date' => $header['purchase_date'],
                'company_id' => $header['company_id'],
                'company_invoice_no' => $header['company_invoice_no'] ?? null,
                'invoice_date' => $header['invoice_date'] ?? null,
                'freight_charges' => $header['freight_charges'] ?? 0,
                'discount_amount' => $header['discount_amount'] ?? 0,
                'gst_amount' => $gstTotal,
                'total_amount' => $totalAmount,
                'payment_status' => 'unpaid',
                'remarks' => $header['remarks'] ?? null,
                'created_by' => $header['created_by'] ?? null,
            ]);

            $itemStmt = $this->db->prepare(
                'INSERT INTO purchase_items (purchase_id, product_id, batch_number, expiry_date, quantity, unit, purchase_price, gst_percent, discount, line_total)
                 VALUES (:pid,:prod,:batch,:exp,:qty,:unit,:price,:gst,:disc,:total)'
            );

            foreach ($items as $item) {
                $lineSubtotal = $item['quantity'] * $item['purchase_price'] - (float)($item['discount'] ?? 0);
                $lineGst = $lineSubtotal * ((float)$item['gst_percent'] / 100);
                $lineTotal = $lineSubtotal + $lineGst;

                $itemStmt->execute([
                    'pid' => $purchaseId,
                    'prod' => $item['product_id'],
                    'batch' => $item['batch_number'] ?? null,
                    'exp' => $item['expiry_date'] ?: null,
                    'qty' => $item['quantity'],
                    'unit' => $item['unit'] ?? null,
                    'price' => $item['purchase_price'],
                    'gst' => $item['gst_percent'] ?? 0,
                    'disc' => $item['discount'] ?? 0,
                    'total' => $lineTotal,
                ]);

                // Auto-update inventory: increase stock + record batch + movement log.
                $productModel->increaseStock(
                    (int)$item['product_id'],
                    (float)$item['quantity'],
                    'purchase',
                    $header['purchase_date'],
                    'purchases',
                    $purchaseId,
                    "Purchase $purchaseNo"
                );
                $productModel->addBatch(
                    (int)$item['product_id'],
                    $item['batch_number'] ?? null,
                    $item['expiry_date'] ?: null,
                    (float)$item['quantity'],
                    (float)$item['purchase_price']
                );
                // Keep the product's last known purchase price current.
                $this->db->prepare('UPDATE products SET purchase_price = :price WHERE id = :id')
                    ->execute(['price' => $item['purchase_price'], 'id' => $item['product_id']]);
            }

            // Auto-update company ledger: this purchase increases what we owe the company.
            $companyModel->postLedgerEntry(
                (int)$header['company_id'],
                $header['purchase_date'],
                'purchase',
                $purchaseNo,
                'purchases',
                $purchaseId,
                $totalAmount,
                0,
                "Purchase $purchaseNo"
            );

            $this->db->commit();
            return $purchaseId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getWithItems(int $purchaseId): ?array
    {
        $purchase = $this->find($purchaseId);
        if (!$purchase) {
            return null;
        }
        $stmt = $this->db->prepare(
            'SELECT pi.*, p.product_name FROM purchase_items pi JOIN products p ON p.id = pi.product_id WHERE purchase_id = :id'
        );
        $stmt->execute(['id' => $purchaseId]);
        $purchase['items'] = $stmt->fetchAll();
        return $purchase;
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT pu.*, c.company_name FROM purchases pu JOIN companies c ON c.id = pu.company_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND pu.purchase_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND pu.purchase_date <= :to';
            $params['to'] = $filters['to'];
        }
        if (!empty($filters['company_id'])) {
            $sql .= ' AND pu.company_id = :cid';
            $params['cid'] = $filters['company_id'];
        }
        if (!empty($filters['payment_status'])) {
            $sql .= ' AND pu.payment_status = :ps';
            $params['ps'] = $filters['payment_status'];
        }
        $sql .= ' ORDER BY pu.purchase_date DESC, pu.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function todaysTotal(): float
    {
        $stmt = $this->db->query('SELECT COALESCE(SUM(total_amount),0) FROM purchases WHERE purchase_date = CURDATE()');
        return (float)$stmt->fetchColumn();
    }

    public function monthlyTotal(): float
    {
        $stmt = $this->db->query(
            'SELECT COALESCE(SUM(total_amount),0) FROM purchases WHERE MONTH(purchase_date)=MONTH(CURDATE()) AND YEAR(purchase_date)=YEAR(CURDATE())'
        );
        return (float)$stmt->fetchColumn();
    }

    public function monthlyChartData(): array
    {
        $stmt = $this->db->query(
            "SELECT DATE_FORMAT(purchase_date, '%Y-%m') as ym, SUM(total_amount) as total
             FROM purchases WHERE purchase_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym ORDER BY ym"
        );
        return $stmt->fetchAll();
    }
}
