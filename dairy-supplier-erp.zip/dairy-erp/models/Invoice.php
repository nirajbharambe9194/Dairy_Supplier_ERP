<?php

class Invoice extends Model
{
    protected string $table = 'invoices';

    public function generateNumber(): string
    {
        $prefix = get_setting('invoice_prefix', 'INV-');
        return generate_document_number($this->db, 'invoices', 'invoice_no', $prefix);
    }

    /**
     * Build an invoice from an existing delivery's line items.
     * Note: the delivery itself already posted a distributor ledger debit at delivery time
     * ("delivery" txn_type). The invoice is the formal billing document for that same amount,
     * so it is recorded here for print/PDF purposes without double-posting the ledger.
     */
    public function generateFromDelivery(int $deliveryId, int $createdBy): int
    {
        $deliveryModel = new Delivery();
        $distributorModel = new Distributor();

        $delivery = $deliveryModel->getWithItems($deliveryId);
        if (!$delivery) {
            throw new InvalidArgumentException('Delivery not found.');
        }

        $this->db->beginTransaction();
        try {
            $invoiceNo = $this->generateNumber();
            $subtotal = 0.0;
            $gstTotal = 0.0;
            foreach ($delivery['items'] as $item) {
                $productModel = new Product();
                $product = $productModel->find((int)$item['product_id']);
                $gstPercent = $product ? (float)$product['gst_percent'] : 0.0;
                $lineAmount = (float)$item['amount'];
                $lineGst = $lineAmount * ($gstPercent / 100);
                $subtotal += $lineAmount;
                $gstTotal += $lineGst;
            }
            $totalAmount = $subtotal + $gstTotal;
            $previousBalance = $distributorModel->getOutstandingBalance((int)$delivery['distributor_id']) - $totalAmount;
            // (subtract $totalAmount because the delivery already posted this debit to the running balance)

            $invoiceId = $this->insert([
                'invoice_no' => $invoiceNo,
                'invoice_date' => $delivery['delivery_date'],
                'distributor_id' => $delivery['distributor_id'],
                'delivery_id' => $deliveryId,
                'subtotal' => $subtotal,
                'gst_amount' => $gstTotal,
                'total_amount' => $totalAmount,
                'previous_balance' => $previousBalance,
                'payment_received' => 0,
                'outstanding_balance' => $previousBalance + $totalAmount,
                'status' => 'unpaid',
                'created_by' => $createdBy,
            ]);

            $itemStmt = $this->db->prepare(
                'INSERT INTO invoice_items (invoice_id, product_id, quantity, rate, gst_percent, line_total)
                 VALUES (:iid,:pid,:qty,:rate,:gst,:total)'
            );
            $productModel = new Product();
            foreach ($delivery['items'] as $item) {
                $product = $productModel->find((int)$item['product_id']);
                $gstPercent = $product ? (float)$product['gst_percent'] : 0.0;
                $lineAmount = (float)$item['amount'];
                $itemStmt->execute([
                    'iid' => $invoiceId,
                    'pid' => $item['product_id'],
                    'qty' => $item['delivered_qty'],
                    'rate' => $item['rate'],
                    'gst' => $gstPercent,
                    'total' => $lineAmount + ($lineAmount * $gstPercent / 100),
                ]);
            }

            $this->db->commit();
            return $invoiceId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function getWithItems(int $invoiceId): ?array
    {
        $invoice = $this->find($invoiceId);
        if (!$invoice) {
            return null;
        }
        $stmt = $this->db->prepare(
            'SELECT ii.*, p.product_name, p.unit FROM invoice_items ii JOIN products p ON p.id = ii.product_id WHERE invoice_id = :id'
        );
        $stmt->execute(['id' => $invoiceId]);
        $invoice['items'] = $stmt->fetchAll();

        $distStmt = $this->db->prepare('SELECT * FROM distributors WHERE id = :id');
        $distStmt->execute(['id' => $invoice['distributor_id']]);
        $invoice['distributor'] = $distStmt->fetch();
        return $invoice;
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT i.*, d.distributor_name FROM invoices i JOIN distributors d ON d.id = i.distributor_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND i.invoice_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND i.invoice_date <= :to';
            $params['to'] = $filters['to'];
        }
        if (!empty($filters['distributor_id'])) {
            $sql .= ' AND i.distributor_id = :did';
            $params['did'] = $filters['distributor_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND i.status = :status';
            $params['status'] = $filters['status'];
        }
        $sql .= ' ORDER BY i.invoice_date DESC, i.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function todaysSalesTotal(): float
    {
        $stmt = $this->db->query('SELECT COALESCE(SUM(total_amount),0) FROM invoices WHERE invoice_date = CURDATE()');
        return (float)$stmt->fetchColumn();
    }

    public function monthlyRevenue(): float
    {
        $stmt = $this->db->query(
            'SELECT COALESCE(SUM(total_amount),0) FROM invoices WHERE MONTH(invoice_date)=MONTH(CURDATE()) AND YEAR(invoice_date)=YEAR(CURDATE())'
        );
        return (float)$stmt->fetchColumn();
    }

    public function monthlyChartData(): array
    {
        $stmt = $this->db->query(
            "SELECT DATE_FORMAT(invoice_date, '%Y-%m') as ym, SUM(total_amount) as total
             FROM invoices WHERE invoice_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
             GROUP BY ym ORDER BY ym"
        );
        return $stmt->fetchAll();
    }

    public function productSalesChartData(): array
    {
        $stmt = $this->db->query(
            'SELECT p.product_name, SUM(ii.quantity) as qty, SUM(ii.line_total) as amount
             FROM invoice_items ii JOIN products p ON p.id = ii.product_id
             JOIN invoices i ON i.id = ii.invoice_id
             WHERE i.invoice_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
             GROUP BY ii.product_id ORDER BY amount DESC LIMIT 8'
        );
        return $stmt->fetchAll();
    }
}
