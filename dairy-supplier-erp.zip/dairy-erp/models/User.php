<?php

class User extends Model
{
    protected string $table = 'users';

    public function findByUsername(string $username): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT u.*, r.role_name FROM users u
             JOIN user_roles r ON r.id = u.role_id
             WHERE u.username = :u1 OR u.email = :u2 LIMIT 1'
        );
        $stmt->execute(['u1' => $username, 'u2' => $username]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function recordFailedLogin(int $userId): void
    {
        $stmt = $this->db->prepare(
            'UPDATE users SET failed_login_attempts = failed_login_attempts + 1,
             locked_until = IF(failed_login_attempts + 1 >= 5, DATE_ADD(NOW(), INTERVAL 15 MINUTE), locked_until)
             WHERE id = :id'
        );
        $stmt->execute(['id' => $userId]);
    }

    public function resetFailedLogins(int $userId): void
    {
        $stmt = $this->db->prepare(
            'UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = :id'
        );
        $stmt->execute(['id' => $userId]);
    }

    public function isLocked(array $user): bool
    {
        return !empty($user['locked_until']) && strtotime($user['locked_until']) > time();
    }

    public function changePassword(int $userId, string $newPlainPassword): bool
    {
        $hash = password_hash($newPlainPassword, PASSWORD_BCRYPT);
        return $this->update($userId, ['password_hash' => $hash]);
    }
}
