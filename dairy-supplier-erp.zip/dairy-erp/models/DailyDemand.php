<?php

class DailyDemand extends Model
{
    protected string $table = 'daily_demands';

    public function getForDate(string $date, int $distributorId = 0): array
    {
        $sql = 'SELECT dd.*, d.distributor_name, p.product_name, p.unit FROM daily_demands dd
                JOIN distributors d ON d.id = dd.distributor_id
                JOIN products p ON p.id = dd.product_id
                WHERE dd.demand_date = :date';
        $params = ['date' => $date];
        if ($distributorId > 0) {
            $sql .= ' AND dd.distributor_id = :did';
            $params['did'] = $distributorId;
        }
        $sql .= ' ORDER BY d.distributor_name, p.product_name';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Insert or update a single distributor/product demand line for a date (upsert). */
    public function upsert(string $date, int $distributorId, int $productId, float $morning, float $evening, float $rate, string $remarks = ''): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO daily_demands (demand_date, distributor_id, product_id, morning_qty, evening_qty, rate, remarks)
             VALUES (:date,:did,:pid,:morning,:evening,:rate,:remarks)
             ON DUPLICATE KEY UPDATE morning_qty = VALUES(morning_qty), evening_qty = VALUES(evening_qty),
                rate = VALUES(rate), remarks = VALUES(remarks)'
        );
        $stmt->execute([
            'date' => $date, 'did' => $distributorId, 'pid' => $productId,
            'morning' => $morning, 'evening' => $evening, 'rate' => $rate, 'remarks' => $remarks,
        ]);
    }

    /** Copy all demand lines from the previous day into a target date (skips lines that already exist). */
    public function copyFromPreviousDay(string $targetDate, int $distributorId = 0): int
    {
        $previousDate = date('Y-m-d', strtotime($targetDate . ' -1 day'));
        $rows = $this->getForDate($previousDate, $distributorId);
        $copied = 0;
        foreach ($rows as $row) {
            $exists = $this->db->prepare(
                'SELECT COUNT(*) FROM daily_demands WHERE demand_date=:d AND distributor_id=:did AND product_id=:pid'
            );
            $exists->execute(['d' => $targetDate, 'did' => $row['distributor_id'], 'pid' => $row['product_id']]);
            if ((int)$exists->fetchColumn() > 0) {
                continue;
            }
            $this->upsert($targetDate, (int)$row['distributor_id'], (int)$row['product_id'], (float)$row['morning_qty'], (float)$row['evening_qty'], (float)$row['rate'], (string)$row['remarks']);
            $copied++;
        }
        return $copied;
    }

    public function deleteLine(int $id): bool
    {
        return $this->delete($id);
    }
}
