<?php

class CompanyPayment extends Model
{
    protected string $table = 'company_payments';

    public function recordPayment(array $data): int
    {
        $companyModel = new Company();
        $this->db->beginTransaction();
        try {
            $newBalance = $companyModel->getOutstandingBalance((int)$data['company_id']) - (float)$data['amount'];

            $paymentId = $this->insert([
                'company_id' => $data['company_id'],
                'payment_date' => $data['payment_date'],
                'invoice_no' => $data['invoice_no'] ?? null,
                'payment_method' => $data['payment_method'],
                'transaction_reference' => $data['transaction_reference'] ?? null,
                'amount' => $data['amount'],
                'outstanding_balance' => $newBalance,
                'remarks' => $data['remarks'] ?? null,
                'created_by' => $data['created_by'] ?? null,
            ]);

            $companyModel->postLedgerEntry(
                (int)$data['company_id'],
                $data['payment_date'],
                'payment',
                $data['transaction_reference'] ?? ('PMT-' . $paymentId),
                'company_payments',
                $paymentId,
                0,
                (float)$data['amount'],
                'Payment made to company'
            );

            $this->db->commit();
            return $paymentId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function listWithFilters(array $filters): array
    {
        $sql = 'SELECT cp.*, c.company_name FROM company_payments cp JOIN companies c ON c.id = cp.company_id WHERE 1=1';
        $params = [];
        if (!empty($filters['from'])) {
            $sql .= ' AND cp.payment_date >= :from';
            $params['from'] = $filters['from'];
        }
        if (!empty($filters['to'])) {
            $sql .= ' AND cp.payment_date <= :to';
            $params['to'] = $filters['to'];
        }
        if (!empty($filters['company_id'])) {
            $sql .= ' AND cp.company_id = :cid';
            $params['cid'] = $filters['company_id'];
        }
        $sql .= ' ORDER BY cp.payment_date DESC, cp.id DESC';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
