<?php

class Report extends Model
{
    protected string $table = 'invoices'; // not used directly; this model is query-only

    public function grossProfitThisMonth(): float
    {
        $stmt = $this->db->query(
            "SELECT COALESCE(SUM(ii.line_total),0) - COALESCE((
                SELECT SUM(ii2.quantity * p.purchase_price)
                FROM invoice_items ii2
                JOIN invoices i2 ON i2.id = ii2.invoice_id
                JOIN products p ON p.id = ii2.product_id
                WHERE MONTH(i2.invoice_date)=MONTH(CURDATE()) AND YEAR(i2.invoice_date)=YEAR(CURDATE())
             ),0)
             FROM invoice_items ii
             JOIN invoices i ON i.id = ii.invoice_id
             WHERE MONTH(i.invoice_date)=MONTH(CURDATE()) AND YEAR(i.invoice_date)=YEAR(CURDATE())"
        );
        return (float)$stmt->fetchColumn();
    }

    public function netProfitThisMonth(): float
    {
        $gross = $this->grossProfitThisMonth();
        $stmt = $this->db->query(
            'SELECT COALESCE(SUM(amount),0) FROM expenses WHERE MONTH(expense_date)=MONTH(CURDATE()) AND YEAR(expense_date)=YEAR(CURDATE())'
        );
        $expenses = (float)$stmt->fetchColumn();
        return $gross - $expenses;
    }

    public function productWiseProfit(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            'SELECT p.product_name,
                    SUM(ii.quantity) as qty_sold,
                    SUM(ii.line_total) as revenue,
                    SUM(ii.quantity * p.purchase_price) as cost,
                    SUM(ii.line_total) - SUM(ii.quantity * p.purchase_price) as profit
             FROM invoice_items ii
             JOIN invoices i ON i.id = ii.invoice_id
             JOIN products p ON p.id = ii.product_id
             WHERE i.invoice_date BETWEEN :from AND :to
             GROUP BY ii.product_id ORDER BY profit DESC'
        );
        $stmt->execute(['from' => $from, 'to' => $to]);
        return $stmt->fetchAll();
    }

    public function distributorWiseProfit(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            'SELECT d.distributor_name,
                    SUM(ii.line_total) as revenue,
                    SUM(ii.quantity * p.purchase_price) as cost,
                    SUM(ii.line_total) - SUM(ii.quantity * p.purchase_price) as profit
             FROM invoice_items ii
             JOIN invoices i ON i.id = ii.invoice_id
             JOIN products p ON p.id = ii.product_id
             JOIN distributors d ON d.id = i.distributor_id
             WHERE i.invoice_date BETWEEN :from AND :to
             GROUP BY i.distributor_id ORDER BY profit DESC'
        );
        $stmt->execute(['from' => $from, 'to' => $to]);
        return $stmt->fetchAll();
    }

    public function stockValuationReport(): array
    {
        return $this->db->query(
            'SELECT product_code, product_name, unit, current_stock, purchase_price,
                    (current_stock * purchase_price) as stock_value
             FROM products ORDER BY stock_value DESC'
        )->fetchAll();
    }

    public function stockMovementReport(string $from, string $to, int $productId = 0): array
    {
        $sql = 'SELECT st.*, p.product_name, p.unit FROM stock_transactions st
                JOIN products p ON p.id = st.product_id
                WHERE st.txn_date BETWEEN :from AND :to';
        $params = ['from' => $from, 'to' => $to];
        if ($productId > 0) {
            $sql .= ' AND st.product_id = :pid';
            $params['pid'] = $productId;
        }
        $sql .= ' ORDER BY st.txn_date, st.id';
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function collectionReport(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            'SELECT dp.*, d.distributor_name FROM distributor_payments dp
             JOIN distributors d ON d.id = dp.distributor_id
             WHERE dp.payment_date BETWEEN :from AND :to ORDER BY dp.payment_date'
        );
        $stmt->execute(['from' => $from, 'to' => $to]);
        return $stmt->fetchAll();
    }
}
