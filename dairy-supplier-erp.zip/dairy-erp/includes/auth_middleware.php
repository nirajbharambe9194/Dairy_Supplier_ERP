<?php

/** Is anyone logged in this session? */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/** Current user's role name ('admin' | 'staff'), or null if not logged in. */
function current_role(): ?string
{
    return $_SESSION['role_name'] ?? null;
}

function current_user_id(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

/** Redirect to login unless authenticated. Call at the top of every protected page. */
function require_login(): void
{
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: ' . APP_URL . '/index.php?page=login');
        exit;
    }
}

/**
 * Restrict a page/action to specific roles. Admin implicitly passes every check.
 * Usage: require_role(['admin']); // admin-only
 */
function require_role(array $roles): void
{
    require_login();
    $role = current_role();
    if ($role === 'admin') {
        return; // Administrator: full access to all modules.
    }
    if (!in_array($role, $roles, true)) {
        http_response_code(403);
        require APP_ROOT . '/views/errors/403.php';
        exit;
    }
}

/** Record an audit-trail entry. Never let logging failures break the request. */
function log_activity(string $action, string $module = '', string $description = ''): void
{
    try {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare(
            'INSERT INTO activity_logs (user_id, action, module, description, ip_address, user_agent)
             VALUES (:uid, :action, :module, :description, :ip, :ua)'
        );
        $stmt->execute([
            'uid' => current_user_id(),
            'action' => $action,
            'module' => $module,
            'description' => $description,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            'ua' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ]);
    } catch (Throwable $e) {
        error_log('activity_log failed: ' . $e->getMessage());
    }
}
