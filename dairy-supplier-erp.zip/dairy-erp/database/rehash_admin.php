<?php
/**
 * Run this ONCE from the command line after importing schema.sql + seed.sql:
 *   php database/rehash_admin.php
 *
 * It sets a fresh, correctly-generated bcrypt hash for the seeded admin/staff
 * accounts using YOUR server's PHP build (hashes are not portable-guaranteed
 * across PHP builds, so we regenerate them here rather than trusting a
 * hard-coded hash in the SQL seed file).
 *
 * Default credentials after running this:
 *   admin / Admin@123
 *   staff / Staff@123
 * CHANGE THESE IMMEDIATELY after first login in a real deployment.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

$db = Database::getInstance()->getConnection();

$users = [
    'admin' => 'Admin@123',
    'staff' => 'Staff@123',
];

foreach ($users as $username => $plainPassword) {
    $hash = password_hash($plainPassword, PASSWORD_BCRYPT);
    $stmt = $db->prepare(
        'UPDATE users SET password_hash = :hash, failed_login_attempts = 0, locked_until = NULL WHERE username = :username'
    );
    $stmt->execute(['hash' => $hash, 'username' => $username]);
    echo "Updated password hash for '$username' and cleared any lockout." . PHP_EOL;
}

echo "Done. You can now log in with the credentials listed in this file's header comment." . PHP_EOL;
