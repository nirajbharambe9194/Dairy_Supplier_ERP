-- ============================================================
-- Dairy Supplier ERP - Database Schema
-- Engine: InnoDB, Charset: utf8mb4
-- ============================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS dairy_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dairy_erp;

-- ------------------------------------------------------------
-- Users & Roles
-- ------------------------------------------------------------
CREATE TABLE user_roles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  role_id INT UNSIGNED NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  avatar VARCHAR(255) DEFAULT NULL,
  status ENUM('active','inactive') DEFAULT 'active',
  last_login DATETIME DEFAULT NULL,
  failed_login_attempts INT UNSIGNED DEFAULT 0,
  locked_until DATETIME DEFAULT NULL,
  remember_token VARCHAR(100) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES user_roles(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Companies (Manufacturers / Suppliers TO us)
-- ------------------------------------------------------------
CREATE TABLE companies (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_code VARCHAR(20) NOT NULL UNIQUE,
  company_name VARCHAR(150) NOT NULL,
  contact_person VARCHAR(100) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  state VARCHAR(100) DEFAULT NULL,
  country VARCHAR(100) DEFAULT 'India',
  gst_number VARCHAR(20) DEFAULT NULL,
  pan_number VARCHAR(20) DEFAULT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  email VARCHAR(100) DEFAULT NULL,
  payment_terms VARCHAR(100) DEFAULT NULL,
  credit_limit DECIMAL(14,2) DEFAULT 0.00,
  opening_balance DECIMAL(14,2) DEFAULT 0.00,
  bank_name VARCHAR(100) DEFAULT NULL,
  bank_account_no VARCHAR(50) DEFAULT NULL,
  bank_ifsc VARCHAR(20) DEFAULT NULL,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_company_status (status),
  INDEX idx_company_name (company_name)
) ENGINE=InnoDB;

CREATE TABLE company_ledgers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  txn_date DATE NOT NULL,
  txn_type ENUM('purchase','purchase_return','payment','opening','adjustment') NOT NULL,
  reference_no VARCHAR(50) DEFAULT NULL,
  reference_table VARCHAR(50) DEFAULT NULL,
  reference_id BIGINT UNSIGNED DEFAULT NULL,
  debit DECIMAL(14,2) DEFAULT 0.00,
  credit DECIMAL(14,2) DEFAULT 0.00,
  running_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
  INDEX idx_cl_company_date (company_id, txn_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Products
-- ------------------------------------------------------------
CREATE TABLE product_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_code VARCHAR(30) NOT NULL UNIQUE,
  product_name VARCHAR(150) NOT NULL,
  category_id INT UNSIGNED DEFAULT NULL,
  brand VARCHAR(100) DEFAULT NULL,
  unit VARCHAR(20) NOT NULL DEFAULT 'Ltr',
  barcode VARCHAR(50) DEFAULT NULL,
  purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  selling_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  gst_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  current_stock DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  minimum_stock DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES product_categories(id) ON DELETE SET NULL,
  INDEX idx_product_status (status),
  INDEX idx_product_name (product_name)
) ENGINE=InnoDB;

-- Batch-level stock (a product can have multiple batches with different expiry)
CREATE TABLE product_batches (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  batch_number VARCHAR(50) NOT NULL,
  expiry_date DATE DEFAULT NULL,
  quantity DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_batch_product (product_id),
  INDEX idx_batch_expiry (expiry_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Purchases (Company -> Supplier)
-- ------------------------------------------------------------
CREATE TABLE purchases (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  purchase_no VARCHAR(30) NOT NULL UNIQUE,
  purchase_date DATE NOT NULL,
  company_id INT UNSIGNED NOT NULL,
  company_invoice_no VARCHAR(50) DEFAULT NULL,
  invoice_date DATE DEFAULT NULL,
  freight_charges DECIMAL(12,2) DEFAULT 0.00,
  discount_amount DECIMAL(12,2) DEFAULT 0.00,
  gst_amount DECIMAL(12,2) DEFAULT 0.00,
  total_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  payment_status ENUM('paid','partial','unpaid') DEFAULT 'unpaid',
  remarks VARCHAR(255) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_purchase_date (purchase_date),
  INDEX idx_purchase_company (company_id)
) ENGINE=InnoDB;

CREATE TABLE purchase_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  purchase_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  batch_number VARCHAR(50) DEFAULT NULL,
  expiry_date DATE DEFAULT NULL,
  quantity DECIMAL(12,3) NOT NULL,
  unit VARCHAR(20) DEFAULT NULL,
  purchase_price DECIMAL(12,2) NOT NULL,
  gst_percent DECIMAL(5,2) DEFAULT 0.00,
  discount DECIMAL(12,2) DEFAULT 0.00,
  line_total DECIMAL(14,2) NOT NULL,
  FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id),
  INDEX idx_pi_product (product_id)
) ENGINE=InnoDB;

CREATE TABLE purchase_returns (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  return_no VARCHAR(30) NOT NULL UNIQUE,
  return_date DATE NOT NULL,
  company_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  batch_number VARCHAR(50) DEFAULT NULL,
  quantity DECIMAL(12,3) NOT NULL,
  rate DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  reason VARCHAR(255) DEFAULT NULL,
  credit_note_no VARCHAR(50) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id),
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Inventory / Stock Ledger (append-only movement log)
-- ------------------------------------------------------------
CREATE TABLE stock_transactions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  txn_date DATE NOT NULL,
  txn_type ENUM('opening','purchase','purchase_return','delivery','damage','adjustment') NOT NULL,
  reference_table VARCHAR(50) DEFAULT NULL,
  reference_id BIGINT UNSIGNED DEFAULT NULL,
  quantity_in DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  quantity_out DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  balance_stock DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_st_product_date (product_id, txn_date)
) ENGINE=InnoDB;

CREATE TABLE inventory (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL UNIQUE,
  opening_stock DECIMAL(12,3) DEFAULT 0.000,
  purchase_stock DECIMAL(12,3) DEFAULT 0.000,
  issued_stock DECIMAL(12,3) DEFAULT 0.000,
  returned_stock DECIMAL(12,3) DEFAULT 0.000,
  damaged_stock DECIMAL(12,3) DEFAULT 0.000,
  adjusted_stock DECIMAL(12,3) DEFAULT 0.000,
  current_stock DECIMAL(12,3) DEFAULT 0.000,
  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Distributors
-- ------------------------------------------------------------
CREATE TABLE distributors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  distributor_code VARCHAR(20) NOT NULL UNIQUE,
  distributor_name VARCHAR(150) NOT NULL,
  shop_name VARCHAR(150) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  route VARCHAR(100) DEFAULT NULL,
  city VARCHAR(100) DEFAULT NULL,
  state VARCHAR(100) DEFAULT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  email VARCHAR(100) DEFAULT NULL,
  gst_number VARCHAR(20) DEFAULT NULL,
  payment_type ENUM('cash','credit') DEFAULT 'credit',
  credit_limit DECIMAL(14,2) DEFAULT 0.00,
  opening_balance DECIMAL(14,2) DEFAULT 0.00,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_distributor_route (route),
  INDEX idx_distributor_status (status)
) ENGINE=InnoDB;

CREATE TABLE distributor_ledgers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  distributor_id INT UNSIGNED NOT NULL,
  txn_date DATE NOT NULL,
  txn_type ENUM('delivery','invoice','payment','opening','adjustment') NOT NULL,
  reference_no VARCHAR(50) DEFAULT NULL,
  reference_table VARCHAR(50) DEFAULT NULL,
  reference_id BIGINT UNSIGNED DEFAULT NULL,
  debit DECIMAL(14,2) DEFAULT 0.00,
  credit DECIMAL(14,2) DEFAULT 0.00,
  running_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (distributor_id) REFERENCES distributors(id) ON DELETE CASCADE,
  INDEX idx_dl_dist_date (distributor_id, txn_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Daily Demand
-- ------------------------------------------------------------
CREATE TABLE daily_demands (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  demand_date DATE NOT NULL,
  distributor_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  morning_qty DECIMAL(10,3) DEFAULT 0.000,
  evening_qty DECIMAL(10,3) DEFAULT 0.000,
  total_qty DECIMAL(10,3) GENERATED ALWAYS AS (morning_qty + evening_qty) STORED,
  rate DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount DECIMAL(14,2) GENERATED ALWAYS AS ((morning_qty + evening_qty) * rate) STORED,
  remarks VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (distributor_id) REFERENCES distributors(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id),
  UNIQUE KEY uq_demand (demand_date, distributor_id, product_id),
  INDEX idx_demand_date (demand_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Deliveries
-- ------------------------------------------------------------
CREATE TABLE deliveries (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  delivery_no VARCHAR(30) NOT NULL UNIQUE,
  delivery_date DATE NOT NULL,
  distributor_id INT UNSIGNED NOT NULL,
  total_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (distributor_id) REFERENCES distributors(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_delivery_date (delivery_date),
  INDEX idx_delivery_distributor (distributor_id)
) ENGINE=InnoDB;

CREATE TABLE delivery_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  delivery_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  ordered_qty DECIMAL(10,3) DEFAULT 0.000,
  delivered_qty DECIMAL(10,3) NOT NULL DEFAULT 0.000,
  short_qty DECIMAL(10,3) GENERATED ALWAYS AS (GREATEST(ordered_qty - delivered_qty,0)) STORED,
  damage_qty DECIMAL(10,3) DEFAULT 0.000,
  rate DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Billing / Invoices (Supplier -> Distributor)
-- ------------------------------------------------------------
CREATE TABLE invoices (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_no VARCHAR(30) NOT NULL UNIQUE,
  invoice_date DATE NOT NULL,
  distributor_id INT UNSIGNED NOT NULL,
  delivery_id INT UNSIGNED DEFAULT NULL,
  subtotal DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  gst_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  total_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  previous_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  payment_received DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  outstanding_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  status ENUM('paid','partial','unpaid') DEFAULT 'unpaid',
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (distributor_id) REFERENCES distributors(id),
  FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_invoice_date (invoice_date),
  INDEX idx_invoice_distributor (distributor_id)
) ENGINE=InnoDB;

CREATE TABLE invoice_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  invoice_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity DECIMAL(10,3) NOT NULL,
  rate DECIMAL(12,2) NOT NULL,
  gst_percent DECIMAL(5,2) DEFAULT 0.00,
  line_total DECIMAL(14,2) NOT NULL,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Payments
-- ------------------------------------------------------------
CREATE TABLE company_payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  payment_date DATE NOT NULL,
  invoice_no VARCHAR(50) DEFAULT NULL,
  payment_method ENUM('cash','bank_transfer','cheque','upi','other') DEFAULT 'cash',
  transaction_reference VARCHAR(100) DEFAULT NULL,
  amount DECIMAL(14,2) NOT NULL,
  outstanding_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (company_id) REFERENCES companies(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_cp_date (payment_date)
) ENGINE=InnoDB;

CREATE TABLE distributor_payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  distributor_id INT UNSIGNED NOT NULL,
  payment_date DATE NOT NULL,
  invoice_no VARCHAR(50) DEFAULT NULL,
  payment_method ENUM('cash','bank_transfer','cheque','upi','other') DEFAULT 'cash',
  transaction_reference VARCHAR(100) DEFAULT NULL,
  amount DECIMAL(14,2) NOT NULL,
  remaining_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  remarks VARCHAR(255) DEFAULT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (distributor_id) REFERENCES distributors(id),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_dp_date (payment_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Expenses
-- ------------------------------------------------------------
CREATE TABLE expenses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  expense_date DATE NOT NULL,
  category VARCHAR(100) NOT NULL,
  description VARCHAR(255) DEFAULT NULL,
  amount DECIMAL(14,2) NOT NULL,
  created_by INT UNSIGNED DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Settings
-- ------------------------------------------------------------
CREATE TABLE settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT DEFAULT NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Activity / Audit Log
-- ------------------------------------------------------------
CREATE TABLE activity_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED DEFAULT NULL,
  action VARCHAR(100) NOT NULL,
  module VARCHAR(50) DEFAULT NULL,
  description VARCHAR(255) DEFAULT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_log_date (created_at)
) ENGINE=InnoDB;

CREATE TABLE error_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  message TEXT,
  file VARCHAR(255),
  line INT,
  trace TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
