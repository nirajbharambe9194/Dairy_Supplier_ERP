USE dairy_erp;

-- Roles
INSERT INTO user_roles (role_name, description) VALUES
('admin', 'Full system access'),
('staff', 'Operational access: purchases, inventory, demand, deliveries, billing, payments, reports');

-- Default admin user -> username: admin / password: Admin@123
-- (hash generated with PHP password_hash('Admin@123', PASSWORD_BCRYPT))
INSERT INTO users (role_id, full_name, username, email, password_hash, phone, status)
VALUES (1, 'System Administrator', 'admin', 'admin@dairyerp.local',
'$2y$10$92IXUNpkjO0rOQ5byMi.YeIiFqDlvTB4dCu9UDcLBb6JqbYGCPAry', '9999999999', 'active');
-- NOTE: run database/rehash_admin.php after import to set a real bcrypt hash on your PHP version.

-- Sample staff user -> username: staff / password: Staff@123
INSERT INTO users (role_id, full_name, username, email, password_hash, phone, status)
VALUES (2, 'Staff User', 'staff', 'staff@dairyerp.local',
'$2y$10$92IXUNpkjO0rOQ5byMi.YeIiFqDlvTB4dCu9UDcLBb6JqbYGCPAry', '9888888888', 'active');

-- Product Categories
INSERT INTO product_categories (category_name) VALUES
('Milk'),('Curd'),('Butter'),('Paneer'),('Ghee'),('Cheese'),
('Lassi'),('Buttermilk'),('Cream'),('Flavoured Milk'),('Ice Cream'),('Other Dairy Products');

-- Sample Companies
INSERT INTO companies (company_code, company_name, contact_person, address, city, state, country, gst_number, pan_number, phone, email, payment_terms, credit_limit, opening_balance, status)
VALUES
('CMP-0001','Amul Dairy Pvt Ltd','Rakesh Shah','GCMMF House, Anand','Anand','Gujarat','India','24AACG1234A1Z5','AACG1234A','9820012345','contact@amul.example','Net 15',500000.00,0.00,'active'),
('CMP-0002','Mother Dairy Ltd','Sunita Verma','Mother Dairy Rd','Delhi','Delhi','India','07AACM5678B1Z2','AACM5678B','9820023456','contact@motherdairy.example','Net 30',300000.00,0.00,'active');

-- Sample Products
INSERT INTO products (product_code, product_name, category_id, brand, unit, barcode, purchase_price, selling_price, gst_percent, current_stock, minimum_stock, status)
VALUES
('PRD-0001','Toned Milk 500ml',1,'Amul','Ltr','8901234500019',24.00,28.00,5.00,0,50,'active'),
('PRD-0002','Full Cream Milk 1L',1,'Amul','Ltr','8901234500026',52.00,60.00,5.00,0,50,'active'),
('PRD-0003','Fresh Curd 400g',2,'Amul','Kg','8901234500033',30.00,38.00,5.00,0,30,'active'),
('PRD-0004','Table Butter 100g',3,'Amul','Pcs','8901234500040',48.00,58.00,12.00,0,20,'active'),
('PRD-0005','Paneer 200g',4,'Mother Dairy','Pcs','8901234500057',65.00,80.00,5.00,0,20,'active');

-- Sample Distributors
INSERT INTO distributors (distributor_code, distributor_name, shop_name, address, route, city, state, phone, email, gst_number, payment_type, credit_limit, opening_balance, status)
VALUES
('DIST-0001','Ravi Traders','Ravi General Store','MG Road','Route A','Panvel','Maharashtra','9822011111','ravi@example.com','27AACR1111A1Z1','credit',50000.00,0.00,'active'),
('DIST-0002','Shanti Distributors','Shanti Kirana','Station Road','Route B','Panvel','Maharashtra','9822022222','shanti@example.com','27AACS2222B1Z2','credit',75000.00,0.00,'active');

-- Settings
INSERT INTO settings (setting_key, setting_value) VALUES
('company_name','My Dairy Supply Co.'),
('company_address','123 Market Yard, Panvel, Maharashtra'),
('company_phone','9800000000'),
('company_email','info@mydairysupply.local'),
('company_gst','27AACD0000A1Z0'),
('invoice_prefix','INV-'),
('purchase_prefix','PUR-'),
('delivery_prefix','DEL-'),
('return_prefix','RET-'),
('financial_year_start','04-01'),
('currency_symbol','Rs.'),
('logo_path',''),
('theme','light');
